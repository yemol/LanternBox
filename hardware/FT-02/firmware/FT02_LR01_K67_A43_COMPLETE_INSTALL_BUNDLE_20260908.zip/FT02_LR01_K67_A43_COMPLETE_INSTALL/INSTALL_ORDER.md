# FT-02 + LR01 K67/A4.3 安装顺序

## 版本

- FT-02: v2.75k67 Self-Test Health Fix A2 + GNSS-Off UX A2
- LR01: A4.3 Compass180 + GNSS Software Switch

## 1. LR01

如果设备当前已经运行 A4.3，不需要重复刷写。

如需刷写，解压 LR01 ZIP，在 LR01 工程目录按既有 PlatformIO 7.0.1 环境构建/上传。

## 2. FT-02

解压 FT-02 ZIP，进入 `FT02_Display_Bringup_v0_1`：

```bash
rm -rf .pio
platformio run --target upload --upload-port /dev/cu.usbmodem2201
```

串口名按 Mac 当前实际枚举替换。

## 3. 实机验收

1. 顶部电池显示 MAX17048 实时百分比，不应出现固定 86%。
2. 设备状态页：19% 等低电量只产生 1 个明确“低电量” WARN。
3. 历史 `UART错1` 若没有继续增长，不再同时产生 Host UART + 通讯错误两个 WARN。
4. Host UART 不再误显示 A0；收到 A2 扩展响应后应识别为 A2。
5. GNSS OFF：状态栏显示已关闭；定位记录不能新启动；地图显示 GNSS关闭；指南针仍工作。
6. GNSS ON：LR01 唤醒 M10，恢复搜星。
7. 指南针：首页独立模块，四方向检查，ENTER 可校准。

## 注意

FT-02 当前 +180° 安装补偿不在 FT-02 重复执行，唯一由 LR01 A4.3 负责。
