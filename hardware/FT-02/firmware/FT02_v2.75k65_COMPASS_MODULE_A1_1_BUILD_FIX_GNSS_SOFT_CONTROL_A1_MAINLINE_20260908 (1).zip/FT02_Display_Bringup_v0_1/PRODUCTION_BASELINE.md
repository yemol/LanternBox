# FT-02 v2.75k65 Mainline Test Candidate

Date: 2026-09-08

## Parent baseline

唯一父基线：用户提供的 `FT02_v2.75k64_WIFI_MODULE_A2_MAINLINE.zip`。

本版仅围绕 Compass Module A1 + GNSS Soft Control A1 扩展。Reader、Audio、FieldManual、输入系统、地图、通讯和 WiFi Module A2 不做架构性修改。

## Added runtime surface

1. 首页新增独立 `指南针` 模块。
2. 罗盘校准从系统自检迁入指南针模块。
3. 系统自检第 2 页接入 LR01 A4.3 GNSS 软件 ON/OFF。
4. GNSS 用户期望状态由 FT-02 NVS 持久化。
5. GNSS OFF 不关闭 QMC5883L 罗盘。
6. FT-02 不保存罗盘 offset / scale，LR01 继续是罗盘单一权威。

## Hardware/runtime invariants

- CardKB2: SDA47 / SCL21 / 0x5F
- LR01 UART: RX7 / TX13
- SD: FSPI Mode3 40 MHz, SCK42 / MOSI2 / MISO1 / CS41
- ES8311: BCLK14 / WS15 / DOUT16 / DIN17
- NS4150B SD/CTRL: GPIO4
- LR01 A4.3 performs the 180° compass installation yaw correction.

## Release gate

本包是实机测试候选，不在实机通过前冻结为生产基线。验收至少包括：

1. 指南针 N/E/S/W 四方向实测。
2. 指南针校准开始、保存、取消、重置。
3. 系统自检 GNSS OFF 后保持关闭并在重启后恢复 OFF。
4. GNSS OFF 时指南针继续实时工作。
5. GNSS ON 后 M10 正常唤醒、搜星并恢复定位。
6. k64 既有 Reader / Audio / FieldManual / WiFi 主线回归不退化。
