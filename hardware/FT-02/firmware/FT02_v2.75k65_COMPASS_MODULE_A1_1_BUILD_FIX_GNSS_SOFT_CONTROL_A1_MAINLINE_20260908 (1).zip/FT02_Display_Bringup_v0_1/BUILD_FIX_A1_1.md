# FT-02 v2.75k65 Compass Module A1.1 Build Fix

修复用户实机构建时出现的：

`Arduino.h: #define DEG_TO_RAD ...` 与 `FT02_CompassUI.cpp` 本地 `constexpr float DEG_TO_RAD` 名称冲突。

处理：

- `DEG_TO_RAD` -> `RAD_PER_DEG`
- 仅修改指南针 UI 内部角度转弧度常量名。
- 不改变数值、不改变罗盘方向算法、不改变 LR01 输出、不改变 GNSS ON/OFF。

建议重新执行：

```bash
rm -rf .pio
platformio run --target upload --upload-port /dev/cu.usbserial-0001
```
