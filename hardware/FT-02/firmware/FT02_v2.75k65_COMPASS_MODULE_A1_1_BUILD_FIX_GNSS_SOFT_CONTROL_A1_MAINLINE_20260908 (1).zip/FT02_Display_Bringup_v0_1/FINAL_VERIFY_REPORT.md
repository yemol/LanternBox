# FT-02 v2.75k65 Compass Module A1 + GNSS Soft Control A1

Final static verification report — 2026-09-08

## Parent baseline

- Parent: `FT02_v2.75k64_WIFI_MODULE_A2_MAINLINE.zip`
- Parent SHA256: `ec858cdae71ba9dc2e5337607b39e47f36942b957e5f4ae3fbce40ea6378b220`
- Derivation: direct from k64, no older FT-02 source used.

## New runtime behavior

- Home page appends an independent `指南针` card as the final module.
- Compass module uses a fixed standard compass rose with 5° ticks, N/E/S/W, NE/SE/SW/NW, live heading pointer, numeric heading and Chinese 8-way direction.
- Compass calibration entry has moved from System Self-Test into the Compass module. `ENTER` opens calibration; calibration exit returns to Compass.
- System Self-Test page 2 uses `ENTER` to toggle GNSS software ON/OFF.
- FT-02 persists the desired GNSS state in NVS namespace `ft02sys`, key `gnss_on`.
- LR01 A4.3 control protocol used exactly: `GNSS_SOFT_ON`, `GNSS_SOFT_OFF`, `GNSS_POWER?`, with `GNSS_POWER_STATE` / `GNSS_POWER_SET` parsing.
- Intentional GNSS OFF is shown as `已关闭` and does not fail GNSS self-test.
- Compass stays available while GNSS is in software standby.
- The +180° physical compass installation yaw correction remains LR01 A4.3-owned; FT-02 applies no second installation offset.

## Static regression results

- `tools/test_audio_regression.py` — PASS
- `tools/test_input_epd_regression.py` — PASS
- `tools/test_field_library_v082.py` — PASS
- `tools/test_pdf_recovery.py --builder tools/build_ft02_field_library.py` — PASS
- `tools/test_compass_gnss_control.py` — PASS

Key integrity result from Field Library / FieldManual regression:

- ELE-P0-01 TOC: 45
- ELE-P0-01 media: 139
- FieldManual manifest CRC: PASS
- FieldManual media CRC: 166/166 PASS

## Frozen-source comparison against k64

The following existing runtime files are byte-for-byte identical to the user-provided k64 parent:

- `src/FT02_AudioLog.cpp`
- `src/FT02_AudioLog.h`
- `src/FT02_AudioLogUI.cpp`
- `src/FT02_ES8311.cpp`
- `src/FT02_FieldLibrary.cpp`
- `src/FT02_InputManager.cpp`
- `src/FT02_WirelessManager.cpp`
- `src/FT02_WirelessManager.h`

The required integration surface changes are limited to page routing, LR01 host protocol/status, System Self-Test, Home Cards, Compass calibration ownership, version/docs, plus the new Compass/GNSS-control source files.

## Full build status

The artifact-generation environment does **not** have PlatformIO installed, so a full ESP32-S3 firmware link/upload was not claimed here. The source-level/static regressions above passed. Final release gate is:

```bash
platformio run
```

followed by real-device tests.

## Real-device acceptance checklist

1. Home page final card opens `指南针`.
2. With device front facing N/E/S/W, heading is approximately 0°/90°/180°/270° after calibration.
3. `ENTER` in Compass opens calibration; save/cancel/reset work; leaving calibration returns to Compass.
4. System Self-Test page 2 `ENTER` switches GNSS OFF; status bar becomes `GPS / 已关闭`.
5. Reboot FT-02/LR01 while desired state is OFF; FT-02 restores LR01 software standby.
6. GNSS OFF does not stop compass heading updates.
7. Switch GNSS ON; LR01 A4.3 wakes M10 and outdoor fix can recover normally.
8. Reader, Audio, Field Library, FieldManual, input, WiFi and existing navigation surfaces show no regression.

## Companion LR01

Use the already supplied LR01 package:

`FT02_LR01_MESH_NATIVE_A2_GNSS_RECOVERY_A4_3_COMPASS180_SOFT_GNSS_PIO701_20260908.zip`

Do not use an LR01 build without the A4.3 software-GNSS control and 180° compass installation correction.
