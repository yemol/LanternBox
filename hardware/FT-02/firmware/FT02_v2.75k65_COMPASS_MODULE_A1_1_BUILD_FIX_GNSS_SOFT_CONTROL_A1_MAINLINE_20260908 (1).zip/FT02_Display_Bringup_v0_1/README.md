# FT-02 v2.75k65 Compass Module A1 + GNSS Soft Control A1

这是从用户提供的 **v2.75k64 WiFi Module A2 Mainline** 直接派生的 **v2.75k65 实机测试候选源码包**。本版新增独立指南针模块和 GNSS 软件开关；既有 Reader、Audio、FieldManual、输入、地图、通讯与 WiFi 主线保持原有实现。

## v2.75k65 新增

- 首页最后新增独立 **指南针** 模块。
- 标准电子罗盘界面：固定 360° 罗盘盘面、N/E/S/W + NE/SE/SW/NW、实时航向指针、数字角度与中文八方位。
- `ENTER` 从指南针进入校准；原系统自检中的罗盘校准快捷入口移除。
- 系统自检第 2 页：`ENTER` 切换 GNSS 软件开启/关闭。
- GNSS 用户期望状态保存到 FT-02 NVS；LR01 重启后自动重新对齐。
- 对接 LR01 A4.3 `GNSS_SOFT_ON` / `GNSS_SOFT_OFF` / `GNSS_POWER?`。
- GNSS 关闭时状态栏显示“已关闭”，系统自检不误报 GNSS 故障，QMC 罗盘继续工作。
- 指南针安装 +180° 修正仅由 LR01 A4.3 执行，FT-02 不重复修正。

### 指南针操作

- 首页 -> `指南针`
- `ENTER`：进入校准
- `B`：返回首页
- `H`：帮助

### GNSS 软件开关

- 首页 -> `设备状态` -> 第 2 页
- `ENTER`：GNSS 开 / 关
- `← / →`：翻页
- `B`：返回

关闭为 u-blox M10 software standby，不是物理断开 K25+ VCC。

## 冻结功能

- ESP32-S3 / 16 MB Flash / 8 MB PSRAM。
- CardKB2：SDA 47、SCL 21、0x5F。
- LR01：RX 7、TX 13，导航与无线单一权威源。
- SD：FSPI Mode3 40 MHz，SCK 42 / MOSI 2 / MISO 1 / CS 41。
- ES8311：BCLK 14 / WS 15 / DOUT 16 / DIN 17，AMIC，MCLK NC。
- NS4150B：SD/CTRL GPIO4；闲置、录音时硬关断。
- 音频播放：PSRAM clean playback、Full-TX、播放期间不刷新计时、静态总时长、46.4 ms pop-safe stop。
- 播放音量：1/10 = 0.10x；后续档位保持既有增量；用户主动调音量时采用 PA-off 安全刷新。
- 录音：PSRAM staging、900 ms EPD/SD settle、5 秒录音计时保留。
- Field Library v0.8.2：Reader clean-slate 刷新 x=0,y=86,w=800,h=394。
- SELECT/BACK/HELP：稳定释放后重新武装；方向键和文本输入保持正常重复。
- 通用 EPD partial hot-idle：350 ms；加上实机约 140 ms powerOff，尾部生命周期控制在约 0.5 秒内。

## 构建

```bash
platformio run
platformio run --target upload --upload-port /dev/cu.usbmodem2201
platformio device monitor --port /dev/cu.usbmodem2201
```

生产环境基于：

- `platform-espressif32 55.03.311`
- `framework-arduinoespressif32 3.3.11`
- `esp32-s3-devkitc1-n16r8`

## 回归检查

```bash
python3 tools/test_audio_regression.py
python3 tools/test_input_epd_regression.py
python3 tools/test_field_library_v082.py
python3 tools/test_pdf_recovery.py --builder tools/build_ft02_field_library.py
python3 tools/test_compass_gnss_control.py
```

## SD 内容

- `SD_ROOT/`：完整运行目录。
- `SD_UPDATE_v0.8.2/`：Field Library v0.8.2 覆盖内容。
- 修改 FieldManual 运行文件时，必须同步更新 `manifest.bin` 的 CRC32，并在打包前验证 media/index/data CRC。

## 文档

主要文档在 `docs/`：

- `FT02_PROJECT_GUIDE.md`
- `LR01_HOST_PROTOCOL_A2.md`
- `FT02_LR01_HOST_INTERFACE_PIN_LOCK.md`
- `FT02_AUDIO_ES8311_PA_WIRING.md`
- Field Library / FieldManual 当前内容与质量文档

## 构建与验收状态

本交付环境未安装 PlatformIO，因此这里不伪报“完整固件已编译通过”。已完成项目静态回归、FieldManual/FieldLibrary 完整性检查、PDF recovery 回归以及 Compass/GNSS 控制专项回归。请在 FT-02 实际 PlatformIO 环境完成 `platformio run` 和实机刷写。

配套 LR01 版本：**A4.3 Compass180 + GNSS Software Switch**。180° 安装方向修正只在 LR01 执行，FT-02 不重复补偿。
