# FT-02 v2.75k61 Production Baseline Freeze

Date: 2026-08-31

## Freeze rule

`v2.75k61` is the functional baseline. Production cleanup may remove documentation history, comments, unreachable development code and generated caches, but must not change runtime behavior or hardware assignments.

## Hardware/runtime invariants

- CardKB2: SDA47 / SCL21 / 0x5F
- LR01 UART: RX7 / TX13
- SD: FSPI Mode3 40 MHz, SCK42 / MOSI2 / MISO1 / CS41
- ES8311: BCLK14 / WS15 / DOUT16 / DIN17, AMIC, MCLK NC
- NS4150B SD/CTRL: GPIO4
- Audio: 44.1 kHz, 16-bit, stereo I2S slots, mono WAV payload
- EPD generic partial hot-idle: 350 ms
- Field Library Reader refresh: x=0,y=86,w=800,h=394

## Audio invariants

- PSRAM clean capture/playback retained.
- Playback Full-TX retained; no whole-block rewind retry.
- Playback elapsed timer remains disabled.
- Playback UI displays total duration only.
- Volume-safe EPD refresh only on explicit user volume adjustment.
- Stop path remains 46.4 ms fade → DAC soft mute → PA off → DAC power-down.
- Volume gain table: 0.10 / 0.18 / 0.30 / 0.46 / 0.60 / 0.75 / 0.90 / 1.10 / 1.35 / 1.60.

## Cleanup performed

- Removed superseded per-version AUDIT/REPORT files.
- Removed obsolete Field Library release notes and historical test-plan archive.
- Consolidated production documentation.
- Removed version-history comments from runtime source.
- Removed the abandoned automatic playback quiet-window scanner and its private constants/helper; it had no runtime callers. The explicit PA-off EPD guard used by volume refresh remains.
- Removed cache/build artifacts and added `.gitignore`.

## Integrity gate

Before commit/release:

1. Run audio, input/EPD, Field Library and PDF recovery regressions.
2. Verify FieldManual manifest CRC and media CRC.
3. Rebuild root SHA256/CRC32 manifests.
4. Read back both checksum manifests.
5. Verify ZIP with `unzip -t`.

## A20 输入与录音 UI 微调

- 录音底栏不再显示“计时区小范围刷新”；录音计时本身保持。
- 页面/选项刷新期间，只有触发刷新的原始按键被等待释放；不同新按键可立即排队，解决导航后快速 ENTER 被吞的问题。


## A21 电子书适宽模式底部可达性

- Scan-PDF 绘制与滚动统一使用 `y=150,h=326`。
- EPUB 媒体绘制与滚动统一使用 `y=152,h=324`。
- 修复旧实现滚动边界多算 26px / 10px，导致页面底部最后一行无法滚入屏幕的问题。

## A22 ScanPDF text-line safe viewport
- ScanPDF fit-width viewport edges snap to nearby horizontal whitespace runs.
- Exact bottom reach from A21 is retained.
- EPUB media path remains unchanged.


## A23 vertical continuous reader

- DOWN scrolls within the current media page; when already at the bottom, the next DOWN enters the next page at scroll 0.
- UP scrolls within the current media page; when already at the top, the next UP enters the previous page at that page's maximum scroll.
- LEFT/RIGHT remain direct previous/next page controls.
- Queued media navigation follows the same rules.
