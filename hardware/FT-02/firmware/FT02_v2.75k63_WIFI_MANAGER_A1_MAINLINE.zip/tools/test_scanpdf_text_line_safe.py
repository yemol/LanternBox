#!/usr/bin/env python3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
cpp=(ROOT/'src/FT02_FieldLibrary.cpp').read_text(encoding='utf-8')

def req(c,m):
    if not c: raise SystemExit('FAIL: '+m)

req('snapScanTextBounds' in cpp, 'snap flag missing')
req('constexpr int kSnapSearchPx = 42' in cpp, '42px local search missing')
req('constexpr int kBlankRunPx = 3' in cpp, 'blank run missing')
req('sourceStartY > 0 && sourceStartY < maxScroll' in cpp, 'final max-scroll bottom priority missing')
req('scanPdf && !g_mediaFitPage' in cpp, 'scope is not ScanPDF fit-width only')
req('[FIELD-LIBRARY-A22] scan-text-safe' in cpp, 'diagnostic missing')

# Synthetic 784x1214 scan page, matching the dominant BLD-P0-01 runtime geometry.
# Rows 0..1213 contain text bands separated by 5-row white gaps. Verify that a
# 326px viewport can move its bottom from a text band to the nearest whitespace
# without exceeding the 42px local search budget.
H=1214
AREA=326
blank=[False]*H
for y in range(20,H,32):
    for r in range(y,min(y+5,H)):
        blank[r]=True

def safe_bottom(start):
    rows=min(AREA,H-start)
    if start+rows>=H:
        return rows
    run=0
    for local in range(rows-1,max(47,rows-42)-1,-1):
        if blank[start+local]:
            run+=1
            if run>=3:
                return local+3
        else:
            run=0
    return rows

for start in [0,260,520,780]:
    rows=safe_bottom(start)
    req(AREA-42 <= rows <= AREA, f'unsafe trim at {start}: {rows}')
    end=start+rows-1
    req(blank[end] or blank[end-1] or blank[end-2], f'end not in whitespace near {start}')

# Exact bottom screen must remain fully reachable.
max_scroll=H-AREA
req(max_scroll+AREA==H, 'bottom reach arithmetic changed')
print('PASS k61 A22 ScanPDF text-line-safe viewport synthetic + source contract')
