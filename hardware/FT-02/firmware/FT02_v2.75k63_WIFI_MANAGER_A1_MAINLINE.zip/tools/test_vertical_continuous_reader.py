#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
cpp = (ROOT / 'src/FT02_FieldLibrary.cpp').read_text(encoding='utf-8')
build = (ROOT / 'src/FT02_BuildInfo.h').read_text(encoding='utf-8')

def req(cond, msg):
    if not cond:
        print('FAIL', msg)
        raise SystemExit(1)

req('"v2.75k61"' in build, 'firmware version')
req('Vertical Continuous Reader A23' in build, 'A23 feature label')
req('static int FT02_LibraryMediaMaxScrollForIndex' in cpp, 'authoritative media max-scroll helper')
req('static bool FT02_LibraryMediaNavigateVertical(int direction)' in cpp, 'vertical navigation helper')
req('if(g_mediaScrollY < maxScroll)' in cpp, 'DOWN must scroll within current page before crossing')
req('if(g_activeMedia + 1 >= g_mediaCount) return false;' in cpp, 'DOWN final-page guard')
req('++g_activeMedia;' in cpp and 'g_mediaScrollY = 0;' in cpp, 'DOWN must enter next page at top')
req('if(g_mediaScrollY > 0)' in cpp, 'UP must scroll within current page before crossing')
req('if(g_activeMedia <= 0) return false;' in cpp, 'UP first-page guard')
req('--g_activeMedia;' in cpp, 'UP must enter previous page')
req('g_mediaScrollY = g_mediaFitPage ? 0 : FT02_LibraryMediaMaxScrollForIndex(g_activeMedia);' in cpp,
    'UP must enter previous fit-width page at bottom')
req(cpp.count('(void)FT02_LibraryMediaNavigateVertical(1);') >= 2,
    'DOWN helper must be used by direct and queued navigation')
req(cpp.count('(void)FT02_LibraryMediaNavigateVertical(-1);') >= 2,
    'UP helper must be used by direct and queued navigation')
req('FT02_LibraryMediaSetIndex(g_activeMedia + 1);' in cpp and 'FT02_LibraryMediaSetIndex(g_activeMedia - 1);' in cpp,
    'LEFT/RIGHT direct page-turn behavior must remain')

# Behavioral model for the boundary rules.
def nav(page, scroll, max_scrolls, direction, fit=False):
    n = len(max_scrolls)
    if direction > 0:
        maxs = 0 if fit else max_scrolls[page]
        if scroll < maxs:
            return page, min(scroll + 260, maxs)
        if page + 1 >= n:
            return page, scroll
        return page + 1, 0
    if scroll > 0:
        return page, max(scroll - 260, 0)
    if page <= 0:
        return page, scroll
    page -= 1
    return page, 0 if fit else max_scrolls[page]

maxs = [874, 910, 820]
req(nav(0, 0, maxs, 1) == (0, 260), 'DOWN internal scroll')
req(nav(0, 874, maxs, 1) == (1, 0), 'DOWN boundary crossing')
req(nav(1, 0, maxs, -1) == (0, 874), 'UP boundary crossing to previous bottom')
req(nav(1, 520, maxs, -1) == (1, 260), 'UP internal scroll')
req(nav(2, 820, maxs, 1) == (2, 820), 'DOWN must stop at final book page')
req(nav(0, 0, maxs, -1) == (0, 0), 'UP must stop at first book page')
req(nav(0, 0, maxs, 1, fit=True) == (1, 0), 'fit-page DOWN acts as next page')

print('PASS k61 A23 vertical continuous reader: DOWN bottom->next top; UP top->previous bottom; LEFT/RIGHT unchanged')
