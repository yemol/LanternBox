#include "FT02_WirelessManager.h"

#include <WiFi.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#include "FT02_BottomBar.h"
#include "FT02_EpdLifecycle.h"
#include "FT02_GlobalCJK20FontData.h"
#include "FT02_GlobalCJKFontData.h"
#include "FT02_GlobalCJKBoldFontData.h"
#include "FT02_LoRaNodeRuntime.h"
#include "FT02_LR01HostRuntime.h"
#include "FT02_StatusBar.h"
#include "FT02_Storage.h"

namespace
{
static constexpr uint8_t FT02_WIFI_MAX_NETWORKS = 9;
static constexpr uint8_t FT02_WIFI_MAX_PROFILES = 8;
static constexpr size_t FT02_WIFI_SSID_LEN = 33;
static constexpr size_t FT02_WIFI_PASSWORD_LEN = 65;
static constexpr uint32_t FT02_WIFI_CONNECT_TIMEOUT_MS = 15000UL;
static constexpr uint32_t FT02_WIFI_PROFILE_MAGIC = 0x32465746UL; // FWF2
static constexpr uint16_t FT02_WIFI_PROFILE_VERSION = 1;

static const char* FT02_WIFI_PROFILE_PATH = "/wifi/wifi_profiles.bin";
static const char* FT02_WIFI_PROFILE_TEMP = "/wifi/wifi_profiles.tmp";
static const char* FT02_WIFI_PROFILE_BACKUP = "/wifi/wifi_profiles.bak";

enum FT02WirelessMenuSelection : uint8_t
{
    FT02_WIRELESS_MENU_WIFI = 0,
    FT02_WIRELESS_MENU_BLE,
    FT02_WIRELESS_MENU_LORA,
    FT02_WIRELESS_MENU_COUNT
};

enum FT02WiFiUiState : uint8_t
{
    FT02_WIFI_UI_OFF = 0,
    FT02_WIFI_UI_STARTING,
    FT02_WIFI_UI_SCANNING,
    FT02_WIFI_UI_LIST,
    FT02_WIFI_UI_PASSWORD,
    FT02_WIFI_UI_CONNECTING,
    FT02_WIFI_UI_CONNECTED,
    FT02_WIFI_UI_ERROR
};

struct FT02WiFiProfile
{
    char ssid[FT02_WIFI_SSID_LEN];
    char password[FT02_WIFI_PASSWORD_LEN];
    int16_t priority;
    uint32_t lastConnected;
};

struct FT02WiFiProfileFileHeader
{
    uint32_t magic;
    uint16_t version;
    uint16_t count;
};

struct FT02WiFiNetworkView
{
    char ssid[FT02_WIFI_SSID_LEN];
    int32_t rssi;
    wifi_auth_mode_t auth;
};

static uint8_t g_wirelessSelected = FT02_WIRELESS_MENU_WIFI;
static FT02WiFiUiState g_wifiUiState = FT02_WIFI_UI_OFF;
static FT02WiFiNetworkView g_networks[FT02_WIFI_MAX_NETWORKS] = {};
static uint8_t g_networkCount = 0;
static uint8_t g_networkSelected = 0;
static FT02WiFiProfile g_profiles[FT02_WIFI_MAX_PROFILES] = {};
static uint8_t g_profileCount = 0;
static bool g_profilesLoaded = false;
static char g_selectedSsid[FT02_WIFI_SSID_LEN] = {};
static char g_passwordInput[FT02_WIFI_PASSWORD_LEN] = {};
static uint8_t g_passwordLength = 0;
static char g_statusLine[96] = "WiFi OFF";
static char g_connectedSsid[FT02_WIFI_SSID_LEN] = {};
static char g_ipText[24] = "--";

static const FT02BottomBarItem WIRELESS_BOTTOM[3] = {
    {nullptr, "↑/↓ 选择"},
    {nullptr, "ENTER 打开"},
    {nullptr, "0/B 返回"}
};

static const FT02BottomBarItem WIFI_OFF_BOTTOM[3] = {
    {nullptr, "1 开启WiFi"},
    {nullptr, "ENTER 选择"},
    {nullptr, "0/B 返回"}
};

static const FT02BottomBarItem WIFI_LIST_BOTTOM[3] = {
    {nullptr, "↑/↓ 选择SSID"},
    {nullptr, "ENTER 连接"},
    {nullptr, "R扫描 / 0返回"}
};

static const FT02BottomBarItem WIFI_PASSWORD_BOTTOM[3] = {
    {nullptr, "输入密码"},
    {nullptr, "ENTER 连接"},
    {nullptr, "退格删除 / 0返回"}
};

static uint32_t nowSeconds()
{
    const time_t t = time(nullptr);
    if(t >= 1704067200) return static_cast<uint32_t>(t);
    return millis() / 1000UL;
}

static void setStatus(const char* text)
{
    snprintf(g_statusLine, sizeof(g_statusLine), "%s", text != nullptr ? text : "");
}

static const char* authText(wifi_auth_mode_t auth)
{
    switch(auth)
    {
        case WIFI_AUTH_OPEN: return "OPEN";
        case WIFI_AUTH_WEP: return "WEP";
        case WIFI_AUTH_WPA_PSK: return "WPA";
        case WIFI_AUTH_WPA2_PSK: return "WPA2";
        case WIFI_AUTH_WPA_WPA2_PSK: return "WPA/WPA2";
        case WIFI_AUTH_WPA2_ENTERPRISE: return "WPA2-ENT";
        case WIFI_AUTH_WPA3_PSK: return "WPA3";
        case WIFI_AUTH_WPA2_WPA3_PSK: return "WPA2/WPA3";
        default: return "UNKNOWN";
    }
}

static bool isPrintableAscii(char c)
{
    const uint8_t code = static_cast<uint8_t>(c);
    return code >= 0x20 && code <= 0x7E;
}

static void sortProfiles()
{
    for(uint8_t i = 0; i < g_profileCount; ++i)
    {
        for(uint8_t j = static_cast<uint8_t>(i + 1); j < g_profileCount; ++j)
        {
            const bool better =
                g_profiles[j].priority > g_profiles[i].priority ||
                (g_profiles[j].priority == g_profiles[i].priority &&
                 g_profiles[j].lastConnected > g_profiles[i].lastConnected);
            if(better)
            {
                FT02WiFiProfile tmp = g_profiles[i];
                g_profiles[i] = g_profiles[j];
                g_profiles[j] = tmp;
            }
        }
    }
}

static bool loadProfiles()
{
    g_profileCount = 0;
    g_profilesLoaded = true;

    FILE* file = FT02_StorageOpenReadFile(FT02_WIFI_PROFILE_PATH);
    if(file == nullptr) return false;

    FT02WiFiProfileFileHeader header = {};
    if(fread(&header, 1, sizeof(header), file) != sizeof(header) ||
       header.magic != FT02_WIFI_PROFILE_MAGIC ||
       header.version != FT02_WIFI_PROFILE_VERSION)
    {
        fclose(file);
        return false;
    }

    const uint16_t count = header.count < FT02_WIFI_MAX_PROFILES
        ? header.count
        : FT02_WIFI_MAX_PROFILES;
    for(uint16_t i = 0; i < count; ++i)
    {
        FT02WiFiProfile profile = {};
        if(fread(&profile, 1, sizeof(profile), file) != sizeof(profile)) break;
        profile.ssid[FT02_WIFI_SSID_LEN - 1] = '\0';
        profile.password[FT02_WIFI_PASSWORD_LEN - 1] = '\0';
        if(profile.ssid[0] == '\0') continue;
        g_profiles[g_profileCount++] = profile;
    }
    fclose(file);
    sortProfiles();
    return g_profileCount > 0;
}

static bool saveProfiles()
{
    if(!FT02_StorageIsReady()) return false;

    sortProfiles();
    (void)FT02_StorageDeleteFile(FT02_WIFI_PROFILE_TEMP);
    FILE* file = FT02_StorageOpenWriteFile(FT02_WIFI_PROFILE_TEMP, true);
    if(file == nullptr) return false;

    FT02WiFiProfileFileHeader header = {};
    header.magic = FT02_WIFI_PROFILE_MAGIC;
    header.version = FT02_WIFI_PROFILE_VERSION;
    header.count = g_profileCount;

    bool ok = fwrite(&header, 1, sizeof(header), file) == sizeof(header);
    for(uint8_t i = 0; ok && i < g_profileCount; ++i)
    {
        ok = fwrite(&g_profiles[i], 1, sizeof(g_profiles[i]), file) == sizeof(g_profiles[i]);
    }
    if(ok) ok = FT02_StorageSyncFile(file);
    fclose(file);

    if(!ok)
    {
        (void)FT02_StorageDeleteFile(FT02_WIFI_PROFILE_TEMP);
        return false;
    }

    (void)FT02_StorageDeleteFile(FT02_WIFI_PROFILE_BACKUP);
    const bool hadProfile = FT02_StorageFileExists(FT02_WIFI_PROFILE_PATH);
    if(hadProfile && !FT02_StorageRenameFile(FT02_WIFI_PROFILE_PATH, FT02_WIFI_PROFILE_BACKUP))
    {
        (void)FT02_StorageDeleteFile(FT02_WIFI_PROFILE_TEMP);
        return false;
    }
    if(!FT02_StorageRenameFile(FT02_WIFI_PROFILE_TEMP, FT02_WIFI_PROFILE_PATH))
    {
        if(hadProfile) (void)FT02_StorageRenameFile(FT02_WIFI_PROFILE_BACKUP, FT02_WIFI_PROFILE_PATH);
        (void)FT02_StorageDeleteFile(FT02_WIFI_PROFILE_TEMP);
        return false;
    }
    (void)FT02_StorageDeleteFile(FT02_WIFI_PROFILE_BACKUP);
    return true;
}

static int findProfile(const char* ssid)
{
    if(ssid == nullptr || ssid[0] == '\0') return -1;
    for(uint8_t i = 0; i < g_profileCount; ++i)
    {
        if(strcmp(g_profiles[i].ssid, ssid) == 0) return i;
    }
    return -1;
}

static void upsertProfile(const char* ssid, const char* password)
{
    if(ssid == nullptr || ssid[0] == '\0') return;
    if(!g_profilesLoaded) loadProfiles();

    int index = findProfile(ssid);
    if(index < 0)
    {
        if(g_profileCount >= FT02_WIFI_MAX_PROFILES)
        {
            sortProfiles();
            index = FT02_WIFI_MAX_PROFILES - 1;
        }
        else
        {
            index = g_profileCount++;
        }
        g_profiles[index].priority = 100;
    }

    snprintf(g_profiles[index].ssid, sizeof(g_profiles[index].ssid), "%s", ssid);
    snprintf(g_profiles[index].password, sizeof(g_profiles[index].password), "%s", password != nullptr ? password : "");
    g_profiles[index].lastConnected = nowSeconds();
    (void)saveProfiles();
}

static bool connectTo(const char* ssid, const char* password)
{
    if(ssid == nullptr || ssid[0] == '\0') return false;

    snprintf(g_statusLine, sizeof(g_statusLine), "连接 %s ...", ssid);
    WiFi.disconnect(false, false);
    delay(100);
    WiFi.begin(ssid, password != nullptr ? password : "");

    const uint32_t start = millis();
    while(millis() - start < FT02_WIFI_CONNECT_TIMEOUT_MS)
    {
        if(WiFi.status() == WL_CONNECTED)
        {
            snprintf(g_connectedSsid, sizeof(g_connectedSsid), "%s", ssid);
            snprintf(g_ipText, sizeof(g_ipText), "%s", WiFi.localIP().toString().c_str());
            upsertProfile(ssid, password);
            setStatus("CONNECTED");
            return true;
        }
        delay(250);
    }

    WiFi.disconnect(false, false);
    return false;
}

static bool trySavedProfiles()
{
    if(!FT02_StorageIsReady())
    {
        setStatus("SD未就绪，跳过保存网络");
        return false;
    }

    if(!loadProfiles())
    {
        setStatus("无保存网络，开始扫描");
        return false;
    }

    for(uint8_t i = 0; i < g_profileCount; ++i)
    {
        if(connectTo(g_profiles[i].ssid, g_profiles[i].password)) return true;
    }
    setStatus("保存网络连接失败，开始扫描");
    return false;
}

static void scanNetworks()
{
    g_networkCount = 0;
    g_networkSelected = 0;
    g_wifiUiState = FT02_WIFI_UI_SCANNING;

    WiFi.scanDelete();
    const int found = WiFi.scanNetworks(false, true);
    if(found <= 0)
    {
        setStatus(found == 0 ? "未发现网络" : "扫描失败");
        g_wifiUiState = FT02_WIFI_UI_ERROR;
        return;
    }

    const uint8_t count = found < FT02_WIFI_MAX_NETWORKS ? found : FT02_WIFI_MAX_NETWORKS;
    for(uint8_t i = 0; i < count; ++i)
    {
        snprintf(g_networks[i].ssid, sizeof(g_networks[i].ssid), "%s", WiFi.SSID(i).c_str());
        g_networks[i].rssi = WiFi.RSSI(i);
        g_networks[i].auth = WiFi.encryptionType(i);
    }
    g_networkCount = count;
    snprintf(g_statusLine, sizeof(g_statusLine), "扫描完成：%u 个网络", static_cast<unsigned>(g_networkCount));
    g_wifiUiState = FT02_WIFI_UI_LIST;
}

static void startWiFi()
{
    g_connectedSsid[0] = '\0';
    snprintf(g_ipText, sizeof(g_ipText), "--");
    g_wifiUiState = FT02_WIFI_UI_STARTING;
    setStatus("开启WiFi...");

    WiFi.persistent(false);
    WiFi.mode(WIFI_STA);
    WiFi.setSleep(true);
    delay(150);

    if(trySavedProfiles())
    {
        g_wifiUiState = FT02_WIFI_UI_CONNECTED;
        return;
    }
    scanNetworks();
}

static void beginPasswordForSelected()
{
    if(g_networkSelected >= g_networkCount) return;
    snprintf(g_selectedSsid, sizeof(g_selectedSsid), "%s", g_networks[g_networkSelected].ssid);
    g_passwordInput[0] = '\0';
    g_passwordLength = 0;
    g_wifiUiState = FT02_WIFI_UI_PASSWORD;
    snprintf(g_statusLine, sizeof(g_statusLine), "输入 %s 密码", g_selectedSsid);
}

static bool connectPasswordInput()
{
    g_wifiUiState = FT02_WIFI_UI_CONNECTING;
    const bool ok = connectTo(g_selectedSsid, g_passwordInput);
    if(ok)
    {
        g_wifiUiState = FT02_WIFI_UI_CONNECTED;
        return true;
    }
    snprintf(g_statusLine, sizeof(g_statusLine), "%s 连接失败", g_selectedSsid);
    g_wifiUiState = FT02_WIFI_UI_LIST;
    return false;
}

static void drawMenuRow(FT02Display& display, uint8_t index, const char* title, const char* detail)
{
    const int y = 190 + static_cast<int>(index) * 58;
    const bool selected = index == g_wirelessSelected;
    if(selected)
    {
        display.fillRect(36, y - 31, 728, 44, GxEPD_BLACK);
        display.setTextColor(GxEPD_WHITE);
    }
    FT02_DrawTextPack(display, ft02_cjk_24b, title, 56, y);
    FT02_DrawTextPack(display, ft02_cjk_20r, detail, 300, y);
    if(selected) display.setTextColor(GxEPD_BLACK);
}

static void drawNetworkRow(FT02Display& display, uint8_t index)
{
    const int y = 197 + static_cast<int>(index) * 27;
    const bool selected = index == g_networkSelected;
    if(selected)
    {
        display.fillRect(34, y - 21, 732, 25, GxEPD_BLACK);
        display.setTextColor(GxEPD_WHITE);
    }

    char ssid[40];
    snprintf(ssid, sizeof(ssid), "%u %s", static_cast<unsigned>(index + 1), g_networks[index].ssid);
    char info[64];
    snprintf(info, sizeof(info), "%s  %lddBm", authText(g_networks[index].auth), static_cast<long>(g_networks[index].rssi));

    FT02_DrawTextPack(display, ft02_cjk_20r, ssid, 48, y);
    const int w = FT02_TextWidthPack(ft02_cjk_20r, info);
    FT02_DrawTextPack(display, ft02_cjk_20r, info, display.width() - 48 - w, y);
    if(selected) display.setTextColor(GxEPD_BLACK);
}

static void drawPasswordMask(FT02Display& display)
{
    char mask[FT02_WIFI_PASSWORD_LEN] = {};
    const uint8_t shown = g_passwordLength < 32 ? g_passwordLength : 32;
    for(uint8_t i = 0; i < shown; ++i) mask[i] = '*';
    if(g_passwordLength > shown)
    {
        snprintf(mask + shown, sizeof(mask) - shown, "...");
    }
    FT02_DrawTextPack(display, ft02_cjk_24r, mask, 52, 280);
}
} // namespace

void FT02_WirelessManagerBegin()
{
    WiFi.persistent(false);
    WiFi.disconnect(false, false);
    WiFi.mode(WIFI_OFF);
    g_wifiUiState = FT02_WIFI_UI_OFF;
    setStatus("WiFi OFF");
    Serial.println("[WIRELESS-A1] boot default WiFi OFF");
}

void FT02_WirelessManagerOpen()
{
    g_wirelessSelected = FT02_WIRELESS_MENU_WIFI;
}

void FT02_WirelessManagerOpenWiFi()
{
    g_wifiUiState = FT02_WIFI_UI_OFF;
    g_networkCount = 0;
    g_networkSelected = 0;
    g_selectedSsid[0] = '\0';
    g_passwordInput[0] = '\0';
    g_passwordLength = 0;
    snprintf(g_ipText, sizeof(g_ipText), "--");
    g_connectedSsid[0] = '\0';
    setStatus("WiFi OFF");
}

void FT02_WirelessManagerCloseWiFi()
{
    WiFi.disconnect(false, false);
    WiFi.scanDelete();
    WiFi.mode(WIFI_OFF);
    g_wifiUiState = FT02_WIFI_UI_OFF;
    setStatus("WiFi OFF");
    Serial.println("[WIRELESS-A1] WiFi page exit: WiFi OFF");
}

void FT02_WirelessManagerPoll(uint32_t nowMs)
{
    (void)nowMs;
    if(g_wifiUiState == FT02_WIFI_UI_CONNECTED && WiFi.status() != WL_CONNECTED)
    {
        setStatus("连接已断开");
        g_wifiUiState = FT02_WIFI_UI_LIST;
        g_connectedSsid[0] = '\0';
        snprintf(g_ipText, sizeof(g_ipText), "--");
    }
}

FT02WirelessAction FT02_WirelessManagerHandleInput(const FT02InputEvent& event)
{
    if(event.key == FT02_KEY_BACK || (event.key == FT02_KEY_CHAR && event.command == '0'))
    {
        return FT02_WIRELESS_ACTION_EXIT_TOOLS;
    }
    if(event.key == FT02_KEY_HELP) return FT02_WIRELESS_ACTION_OPEN_HELP;

    if(event.key == FT02_KEY_UP)
    {
        g_wirelessSelected = g_wirelessSelected == 0
            ? FT02_WIRELESS_MENU_COUNT - 1
            : static_cast<uint8_t>(g_wirelessSelected - 1);
        return FT02_WIRELESS_ACTION_REDRAW;
    }
    if(event.key == FT02_KEY_DOWN)
    {
        g_wirelessSelected = static_cast<uint8_t>((g_wirelessSelected + 1) % FT02_WIRELESS_MENU_COUNT);
        return FT02_WIRELESS_ACTION_REDRAW;
    }
    if(event.key == FT02_KEY_CHAR)
    {
        if(event.command == '1') g_wirelessSelected = FT02_WIRELESS_MENU_WIFI;
        else if(event.command == '2') g_wirelessSelected = FT02_WIRELESS_MENU_BLE;
        else if(event.command == '3') g_wirelessSelected = FT02_WIRELESS_MENU_LORA;
        else return FT02_WIRELESS_ACTION_NONE;
        return g_wirelessSelected == FT02_WIRELESS_MENU_WIFI
            ? FT02_WIRELESS_ACTION_OPEN_WIFI
            : FT02_WIRELESS_ACTION_REDRAW;
    }
    if(event.key == FT02_KEY_SELECT)
    {
        if(g_wirelessSelected == FT02_WIRELESS_MENU_WIFI) return FT02_WIRELESS_ACTION_OPEN_WIFI;
        return FT02_WIRELESS_ACTION_REDRAW;
    }
    return FT02_WIRELESS_ACTION_NONE;
}

FT02WirelessAction FT02_WirelessManagerHandleWiFiInput(const FT02InputEvent& event)
{
    if(g_wifiUiState == FT02_WIFI_UI_PASSWORD)
    {
        if(event.key == FT02_KEY_SELECT)
        {
            (void)connectPasswordInput();
            return FT02_WIRELESS_ACTION_REDRAW;
        }
        if(static_cast<uint8_t>(event.raw) == 0x08)
        {
            if(g_passwordLength > 0)
            {
                g_passwordInput[--g_passwordLength] = '\0';
                return FT02_WIRELESS_ACTION_REDRAW;
            }
            g_wifiUiState = FT02_WIFI_UI_LIST;
            return FT02_WIRELESS_ACTION_REDRAW;
        }
        if(event.raw == 0x1B || (event.raw == '0' && g_passwordLength == 0))
        {
            g_wifiUiState = FT02_WIFI_UI_LIST;
            return FT02_WIRELESS_ACTION_REDRAW;
        }
        if(isPrintableAscii(event.raw) && g_passwordLength + 1 < FT02_WIFI_PASSWORD_LEN)
        {
            g_passwordInput[g_passwordLength++] = event.raw;
            g_passwordInput[g_passwordLength] = '\0';
            return FT02_WIRELESS_ACTION_REDRAW;
        }
        return FT02_WIRELESS_ACTION_NONE;
    }

    if(event.key == FT02_KEY_BACK || (event.key == FT02_KEY_CHAR && event.command == '0'))
    {
        FT02_WirelessManagerCloseWiFi();
        return FT02_WIRELESS_ACTION_EXIT_TOOLS;
    }
    if(event.key == FT02_KEY_HELP) return FT02_WIRELESS_ACTION_OPEN_HELP;

    if(event.key == FT02_KEY_CHAR && event.command == '1')
    {
        startWiFi();
        return FT02_WIRELESS_ACTION_REDRAW;
    }

    if(g_wifiUiState == FT02_WIFI_UI_CONNECTED)
    {
        if(event.key == FT02_KEY_CHAR && event.command == 'r')
        {
            FT02_WirelessManagerCloseWiFi();
            startWiFi();
            return FT02_WIRELESS_ACTION_REDRAW;
        }
        return FT02_WIRELESS_ACTION_NONE;
    }

    if(g_wifiUiState == FT02_WIFI_UI_LIST && g_networkCount > 0)
    {
        if(event.key == FT02_KEY_UP)
        {
            g_networkSelected = g_networkSelected == 0
                ? static_cast<uint8_t>(g_networkCount - 1)
                : static_cast<uint8_t>(g_networkSelected - 1);
            return FT02_WIRELESS_ACTION_REDRAW;
        }
        if(event.key == FT02_KEY_DOWN)
        {
            g_networkSelected = static_cast<uint8_t>((g_networkSelected + 1) % g_networkCount);
            return FT02_WIRELESS_ACTION_REDRAW;
        }
        if(event.key == FT02_KEY_SELECT)
        {
            if(g_networks[g_networkSelected].auth == WIFI_AUTH_OPEN)
            {
                snprintf(g_selectedSsid, sizeof(g_selectedSsid), "%s", g_networks[g_networkSelected].ssid);
                g_passwordInput[0] = '\0';
                g_passwordLength = 0;
                (void)connectPasswordInput();
            }
            else
            {
                beginPasswordForSelected();
            }
            return FT02_WIRELESS_ACTION_REDRAW;
        }
        if(event.key == FT02_KEY_CHAR && event.command >= '1' && event.command <= '9')
        {
            const uint8_t selected = static_cast<uint8_t>(event.command - '1');
            if(selected < g_networkCount)
            {
                g_networkSelected = selected;
                if(g_networks[g_networkSelected].auth == WIFI_AUTH_OPEN)
                {
                    snprintf(g_selectedSsid, sizeof(g_selectedSsid), "%s", g_networks[g_networkSelected].ssid);
                    g_passwordInput[0] = '\0';
                    g_passwordLength = 0;
                    (void)connectPasswordInput();
                }
                else
                {
                    beginPasswordForSelected();
                }
                return FT02_WIRELESS_ACTION_REDRAW;
            }
        }
    }

    if((g_wifiUiState == FT02_WIFI_UI_LIST || g_wifiUiState == FT02_WIFI_UI_ERROR) &&
       event.key == FT02_KEY_CHAR && event.command == 'r')
    {
        scanNetworks();
        return FT02_WIRELESS_ACTION_REDRAW;
    }

    return FT02_WIRELESS_ACTION_NONE;
}

void FT02_DrawWirelessManagerScreen(FT02Display& display)
{
    display.setFullWindow();
    display.firstPage();
    do
    {
        display.fillScreen(GxEPD_WHITE);
        FT02_DrawStatusBar(display);
        FT02_DrawTextPack(display, ft02_cjk_24b, "Wireless Manager", 32, 112);
        FT02_DrawTextPack(display, ft02_cjk_20r, "System Tools / Wireless Manager", 32, 143);
        display.drawLine(32, 158, 768, 158, GxEPD_BLACK);

        const char* loraDetail = FT02_LoRaNodeRuntimeReady()
            ? "READY"
            : (FT02_LR01HostOnline() ? "SYNC" : "OFFLINE");
        char loraLine[64];
        snprintf(loraLine, sizeof(loraLine), "%s  nodes=%u",
                 loraDetail,
                 static_cast<unsigned>(FT02_LoRaNodeRuntimeNodeCount()));

        drawMenuRow(display, FT02_WIRELESS_MENU_WIFI, "1 WiFi", "OFF / on demand");
        drawMenuRow(display, FT02_WIRELESS_MENU_BLE, "2 BLE", "预留");
        drawMenuRow(display, FT02_WIRELESS_MENU_LORA, "3 LoRa Status", loraLine);

        FT02_DrawTextPack(display, ft02_cjk_20r, "WiFi默认关闭；进入WiFi页并按1后才启动。", 48, 394);
        FT02_DrawBottomBarWithFont(display, WIRELESS_BOTTOM, ft02_cjk_20r);
    }
    while(display.nextPage());
    FT02_EpdPowerOffAfterCommit(display, "wireless-manager-full");
}

void FT02_DrawWirelessWiFiScreen(FT02Display& display)
{
    display.setFullWindow();
    display.firstPage();
    do
    {
        display.fillScreen(GxEPD_WHITE);
        FT02_DrawStatusBar(display);
        FT02_DrawTextPack(display, ft02_cjk_24b, "WiFi", 32, 112);
        FT02_DrawTextPack(display, ft02_cjk_20r, "System Tools / Wireless Manager / WiFi", 32, 143);
        display.drawLine(32, 158, 768, 158, GxEPD_BLACK);

        FT02_DrawTextPack(display, ft02_cjk_24r, "状态:", 48, 197);
        FT02_DrawTextPack(display, ft02_cjk_24b,
                          g_wifiUiState == FT02_WIFI_UI_CONNECTED ? "CONNECTED" :
                          (g_wifiUiState == FT02_WIFI_UI_OFF ? "OFF" : "ON"),
                          142, 197);

        if(g_wifiUiState == FT02_WIFI_UI_OFF)
        {
            FT02_DrawTextPack(display, ft02_cjk_24r, "1 开启WiFi", 48, 254);
            FT02_DrawTextPack(display, ft02_cjk_24r, "0 返回", 48, 302);
            FT02_DrawTextPack(display, ft02_cjk_20r, "不开启扫描，不自动连接，不后台运行。", 48, 370);
            FT02_DrawBottomBarWithFont(display, WIFI_OFF_BOTTOM, ft02_cjk_20r);
        }
        else if(g_wifiUiState == FT02_WIFI_UI_CONNECTED)
        {
            char ssidLine[96];
            snprintf(ssidLine, sizeof(ssidLine), "SSID: %s", g_connectedSsid);
            char ipLine[64];
            snprintf(ipLine, sizeof(ipLine), "IP: %s", g_ipText);
            FT02_DrawTextPack(display, ft02_cjk_24r, ssidLine, 48, 254);
            FT02_DrawTextPack(display, ft02_cjk_24r, ipLine, 48, 302);
            FT02_DrawTextPack(display, ft02_cjk_20r, "R 重新连接/扫描；退出本页会关闭WiFi。", 48, 370);
            FT02_DrawBottomBarWithFont(display, WIFI_LIST_BOTTOM, ft02_cjk_20r);
        }
        else if(g_wifiUiState == FT02_WIFI_UI_PASSWORD)
        {
            char ssidLine[96];
            snprintf(ssidLine, sizeof(ssidLine), "SSID: %s", g_selectedSsid);
            FT02_DrawTextPack(display, ft02_cjk_24r, ssidLine, 48, 226);
            FT02_DrawTextPack(display, ft02_cjk_20r, "Password:", 48, 254);
            drawPasswordMask(display);
            FT02_DrawBottomBarWithFont(display, WIFI_PASSWORD_BOTTOM, ft02_cjk_20r);
        }
        else if(g_wifiUiState == FT02_WIFI_UI_LIST)
        {
            for(uint8_t i = 0; i < g_networkCount; ++i)
            {
                drawNetworkRow(display, i);
            }
            FT02_DrawBottomBarWithFont(display, WIFI_LIST_BOTTOM, ft02_cjk_20r);
        }
        else
        {
            FT02_DrawTextPack(display, ft02_cjk_24r, g_statusLine, 48, 254);
            FT02_DrawTextPack(display, ft02_cjk_20r, "R 重新扫描 / 0 返回", 48, 330);
            FT02_DrawBottomBarWithFont(display, WIFI_OFF_BOTTOM, ft02_cjk_20r);
        }

        FT02_DrawTextPack(display, ft02_cjk_20r, g_statusLine, 48, 420);
    }
    while(display.nextPage());
    FT02_EpdPowerOffAfterCommit(display, "wireless-wifi-full");
}
