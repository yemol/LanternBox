## v2.75k61

- A23 Vertical Continuous Reader: UP/DOWN continue across media-page boundaries after reaching the current page edge; DOWN enters the next page at its top, UP enters the previous page at its bottom. LEFT/RIGHT direct page turns are unchanged.
- Queued UP/DOWN navigation uses the same boundary-crossing logic, preventing rapid navigation from stalling at page edges.
- A21/A22 ScanPDF bottom-reach/text-line-safe viewport behavior remains unchanged.

## v2.75k60

- A22 ScanPDF Text-Line Safe Viewport: fit-width scan pages snap viewport top/bottom to nearby horizontal whitespace runs, preventing the last visible Chinese text line from being sliced by the raster viewport edge.
- Keeps A21 exact bottom reach. Final max-scroll screen is not top-snapped, so the real page bottom remains reachable.
- EPUB media rendering is unchanged from k59.
- Audio, input, recording, EPD timing, FieldManual and volume behavior unchanged.

# Production lineage

## v2.75k59

- 修复 scan-PDF / EPUB “适宽”阅读模式底部内容不可达。
- Scan-PDF 的绘制视口与滚动视口统一为 `y=150,h=326`，消除旧代码 26 px 偏差。
- EPUB 媒体视口统一为 `y=152,h=324`，同时消除 10 px 偏差。
- k58 的 A20 快速确认、录音 UI、音频、Reader clean-slate 与输入策略保持不变。

## v2.75k58

- 录音页底栏移除“计时区小范围刷新”提示；5 秒录音计时功能保持不变。
- EPD BUSY 输入等待改为 owner-aware：只抑制触发刷新的原按键重复值，不再吞掉刷新期间出现的不同新按键。
- 支持方向键切换后立即按 ENTER，ENTER 可直接进入 FIFO 并在刷新结束后执行。
- 保持 k57 的 350 ms hot-idle、A18 音量曲线、音量安全刷新、Reader clean-slate 与音频基线不变。

## v2.75k57

- 通用 EPD partial hot-idle 从 2500 ms 缩短到 350 ms。
- Input stable-release 保持 48 ms；same-key repeat 保持 180 ms。
- 不改变音频、Reader clean-slate、音量安全刷新和 A18 音量曲线。

## v2.75k56

- 1/10 用户播放增益从 0.20x 调整到 0.10x。
- 后续每档增量保持不变，最终表：`0.10, 0.18, 0.30, 0.46, 0.60, 0.75, 0.90, 1.10, 1.35, 1.60`。

## v2.75k55

- 用户主动调音量时恢复屏幕音量显示。
- 快速连续音量键合并 220 ms；刷新期间冻结 PCM、关闭 PA，刷新后从同一 PCM 位置恢复。

## v2.75k54

- Field Library Reader 每页清理并重绘 `x=0,y=86,w=800,h=394`，解决旧画面残留。
- SELECT/BACK/HELP 采用稳定释放后重新武装的一次性输入策略。

## v2.75k50

- 播放页固定显示总时长，不再刷新播放已用时间。
- 播放期间无自动 EPD timer refresh。
- 保留 PSRAM clean playback、Full-TX、RX suspend、46.4 ms stop fade 和 DAC mute → PA shutdown → DAC power-down。
