# FT-02 Field Library v0.6

## 目标
针对实机反馈解决两类问题：EPUB 插图过小模糊，以及翻页后首行/图注重复。

## 插图策略
- EPUB 图片不再挤进文字页剩余高度。
- 图片标记出现在正文流时，如果本页已有文字，则本页在标记前结束。
- 下一页成为该图片的专用阅读页。
- Builder 对小于 720 px 的 EPUB 图片先在灰度域高质量放大，再进行线稿判定、锐化与二值化/抖动。
- 设备端优先 1:1 显示 720 px 图像；竖向超高图片以分段滚动方式阅读。

## 分页策略
- `g_readerNextOffset` 不再依赖循环结束时的 `ftell()` 推断，而是显式跟踪“下一未读字节”。
- 图像 marker 被延后时，next offset 精确指向 marker 起点。
- Builder 去除相邻重复短标题，以及图片 marker 后与 media caption 完全相同的重复图注。

## 兼容
旧进度 `T\tchapter\toffset` 仍可读取；新进度增加可选第四列保存 inline image scroll。
