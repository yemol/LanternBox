# FT-02 Field Library v0.6 集成验证报告

版本：v2.75k30

## 实机反馈修复目标

1. EPUB 插图过小、二值化后模糊。
2. 图片/文字翻页后下一页首行出现重复。

## 修复

- EPUB 小图在 Builder 端先放大到 720 px，再根据白底线稿特征自动选择线稿增强或 Floyd-Steinberg。
- 正文中的图片不再塞进文字页剩余高度，而是变成独立全宽图片页。
- 图片按 720 px 近 1:1 显示；竖图通过连续翻页分段查看。
- Builder 去除图片 marker 后与 caption 完全相同的重复图注。
- Builder 去除相邻的重复短标题。
- Reader 显式维护 nextUnreadOffset，分页边界不再依赖循环结束时的 ftell 推断。
- EPUB 图片页滚动位置写入阅读进度。

## 数据验证

- A6 Validator：PASS
- P0 books: 3
- chapters: 168
- media: 1527
- inline markers: 1279
- AGR-P0-01 marker 后重复 caption: 0
- EPUB media width：SUR/AGR 均统一为 720 px
- BLD 扫描 PDF 页宽：784 px

## 代码验证

- `build_ft02_field_library.py`: Python 语法 PASS
- `FT02_FieldLibrary.cpp`: C++17 syntax-only PASS（本地 stub 环境）
- 完整 PlatformIO 链接仍需 FT-02 本机工具链验证。
