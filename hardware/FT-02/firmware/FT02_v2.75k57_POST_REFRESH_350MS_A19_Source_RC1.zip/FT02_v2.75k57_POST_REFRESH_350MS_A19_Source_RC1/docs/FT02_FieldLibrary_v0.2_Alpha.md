# FT-02 Field Library v0.2 Alpha

## 目标

第一批只加载 P0 级中文资料，并把 EPUB、目录、简单查询纳入稳定数据结构。

## EPUB 运行方式

FT-02 不在 ESP32-S3 上实时运行完整 EPUB 浏览器。PC 端 Builder 接收原始 `book.epub`，保留为 `source.epub`，并解析 EPUB 的 OPF/spine/nav/NCX，生成：

```text
/library/books/<ID>/
  source.epub
  metadata.json
  toc.tsv
  chapters/
    0000.txt
    0001.txt
    ...
```

设备端只读取 UTF-8 章节缓存。这样可以稳定获得目录、分页、进度与查询，并避免在电子纸终端上处理 ZIP/XML/CSS/layout 的高内存和高延迟成本。

## Catalog v0.2

```text
id  title  author  category  priority  format  root  toc
```

Tab 分隔。正式第一批只接受 `priority=P0`。

## 功能

- P0-only Catalog 过滤
- EPUB/TXT 导入
- EPUB 目录解析
- 目录页与章节跳转
- 自动跨章节下一页
- 阅读进度：`chapter + byte offset`
- 中文拼音查询输入
- 简单查询：书名 / 作者 / 分类 / 目录标题 / 正文
- 查询结果直接跳转至命中章节和位置
- v0.1 五列 TXT catalog 兼容读取

## 搜索边界

v0.2 是轻量查询，不是全文检索数据库：

- 中文为 UTF-8 子串匹配；英文 ASCII 不区分大小写；
- 每个章节返回第一个正文命中；
- 总结果最多 48 条；
- 首批 P0 规模很小，因此直接流式扫描章节，避免提前构建巨型中文 n-gram 索引。

后续书库扩大后再升级持久化全文索引。

## 导入

```bash
python3 tools/build_ft02_field_library.py <source_books> <SD_ROOT/library>
python3 tools/validate_ft02_field_library.py <SD_ROOT/library>
```

每本书目录：

```text
<source_books>/<ID>/
  metadata.json
  book.epub
```

`metadata.json` 示例：

```json
{
  "title": "示例中文书",
  "author": "作者",
  "category": "生存技能",
  "priority": "P0"
}
```

默认 Builder 会跳过非 P0。仅调试时可使用 `--allow-non-p0`。

## 实机验收

1. 首页第二页进入“随身书库”。
2. 确认测试 EPUB 显示为 `epub`。
3. 打开书后 ENTER 进入目录，选择章节跳转。
4. 左右翻页，确认章节结束后自动进入下一章。
5. 退出重进，确认恢复到相同章节和位置。
6. 首页进入“查询资料”，用中文拼音输入“保险”或“水源”。
7. 打开查询结果，确认跳转到对应章节。
