# FT-02 Field Library v0.4 Readability Fix

## Real-device issues addressed
1. EPUB image frame visible but pixels missing.
2. ScanPDF Chinese text too soft.
3. EPUB paragraph gaps too large.
4. Page navigation appeared to perform full refreshes.
5. Reader content area too small.

## v0.4 behavior
- Top system status bar remains. Reader/media bottom command bar is removed.
- Text reader: 12 lines, 760 px text width.
- Media/ScanPDF: 784 px reading width.
- EPUB PBM drawing is width-alignment independent.
- Fit-width always uses the full media width, including small EPUB figures.
- ScanPDF import extracts the original page raster when possible and applies technical-text preprocessing before 1-bit conversion.
- Reader/media updates use partial refresh below y=86; clean full refresh after 60 partial commits.
- Clock/GNSS/LoRa UI refreshes are cached while Library is active.
