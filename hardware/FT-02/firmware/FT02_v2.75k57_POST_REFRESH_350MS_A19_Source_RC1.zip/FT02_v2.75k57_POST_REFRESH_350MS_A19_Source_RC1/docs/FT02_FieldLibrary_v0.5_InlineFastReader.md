# FT-02 Field Library v0.5 Inline / Fast Reader

## Real-device fixes

- EPUB images are now embedded in the chapter text flow as `[[IMG:n]]` markers and rendered automatically in the reading page. `I` remains an optional full-image inspector, not the primary way to see figures.
- Normal text page turns update only the 768 x 335 body region. The title/chapter rows refresh only when the chapter changes.
- The reader header now shows stable chapter progress instead of per-page byte percentage, so it can remain untouched during normal page turns.
- Reading partial updates keep the SSD1677 panel powered for the reading session; the generic 2.5 s power-off is not scheduled after every page.
- Cleanup full refresh threshold is raised from 60 to 240 partial turns.
- Navigation keys captured while BUSY are coalesced so several rapid turns result in one final panel commit.
- Standalone media page counters are moved into the media body so the book-title row stays static while paging.

## Physical panel limit

GDEQ0426T82 / SSD1677 fast partial refresh is specified by GxEPD2 at roughly 600 ms. Firmware can remove unnecessary power-on/full-area work and batch keys, but cannot make the e-paper waveform instantaneous.
