# FT-02 Field Library v0.2 Alpha Integration Report

Baseline: FT-02 v2.75k23 Field Library v0.1 Alpha.
Release identity: `v2.75k24`.

## Code changes

- Catalog upgraded from 5 columns to v0.2 8-column model with priority/format/root/toc.
- Firmware enforces P0-only first batch while retaining legacy v0.1 TXT catalog compatibility.
- Reading progress upgraded from one TXT byte offset to `chapter + offset`.
- Added active-book TOC parser and TOC UI.
- Added EPUB chapter navigation and automatic next-chapter paging.
- Added Library query UI with existing FT-02 Pinyin IME and shared CN/EN mode.
- Query streams book metadata, TOC and chapter text; results jump to the hit location.
- Reader `S` opens query; reader `ENTER` opens TOC.
- Builder accepts EPUB and TXT. EPUB source is preserved while generating lightweight runtime cache.
- Added P0 package validator.

## Validation in this environment

- Python builder syntax: PASS.
- Synthetic EPUB3 OPF/spine/nav extraction: PASS.
- P0-only import filter: PASS.
- Generated TOC and UTF-8 chapter cache: PASS.
- `validate_ft02_field_library.py`: PASS (2 books / 6 chapters / P0-only).
- Host C++ syntax check for `FT02_FieldLibrary.cpp`: PASS with local Arduino/GxEPD syntax stubs.

## Not claimed

PlatformIO is not installed in this execution environment, so a full firmware link/build and physical-device verification are not claimed here.
