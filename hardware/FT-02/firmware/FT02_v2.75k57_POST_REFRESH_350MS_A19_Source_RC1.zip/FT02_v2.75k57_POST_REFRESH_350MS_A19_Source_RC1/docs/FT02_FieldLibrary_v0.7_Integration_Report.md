# FT-02 Field Library v0.7 集成验证报告

版本：v2.75k31

- Home Card：随身书库 28px 视觉尺寸与现有菜单卡一致；缺失“书”字以嵌入 28px 字形补齐。
- 阅读排版：正文 30px 行进距，段落后额外 4px，最大 10 行/页。
- EPUB 插图：正文内联默认 fit-page；I 键保留 fit-width/滚动放大。
- Builder：EPUB 图片自动裁剪近白外围边距，再进行 720px 灰度放大、线稿增强与 PBM 生成。
- 恢复阅读：新状态目录 `/lanternbox/library`，兼容并自动迁移旧 `/library/user` 进度。
- 书库验证：3 本 P0，168 章节，1527 媒体，1279 内联图片标记，A6 gate PASS。
- Python Builder/Validator py_compile：PASS。
- FT02_HomeCards.cpp clang++ C++17 syntax：PASS（本地 stub）。
- FT02_FieldLibrary.cpp clang++ C++17 syntax：PASS（本地 stub）。
- 当前环境未执行完整 PlatformIO ESP32-S3 链接/实机刷写。
