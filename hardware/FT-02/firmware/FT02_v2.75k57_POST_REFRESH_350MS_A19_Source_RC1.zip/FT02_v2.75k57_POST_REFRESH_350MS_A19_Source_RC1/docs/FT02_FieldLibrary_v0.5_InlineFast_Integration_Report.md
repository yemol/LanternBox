# FT-02 Field Library v0.5 Inline / Fast Reader Integration Report

## Real-device issues addressed

1. EPUB figures are now inserted into the chapter runtime stream with stable `[[IMG:n]]` markers and rendered automatically in normal reading flow.
2. Standalone `I` image mode remains only for inspection/zoom.
3. Normal text page turns refresh only the 768×335 body area. Header rows refresh only on chapter transitions.
4. The generic 2.5 s panel power-off is not scheduled after Field Library reading partial updates, eliminating repeated SSD1677 power-on latency between normal page turns.
5. Queued navigation keys captured during BUSY are coalesced before the next display commit.
6. Cleanup full-refresh budget is 240 reading partial commits.
7. EPUB validation now verifies every inline image marker resolves to a media entry in the same chapter.

## Runtime data validation

- Books: 3
- Chapters / TOC nodes: 168
- Media items: 1524
- Inline EPUB image markers: 1276
- P0-only: YES
- A6 admission gate: YES

## Panel floor

The GDEQ0426T82 / SSD1677 driver used by FT-02 declares a fast-partial refresh time of about 600 ms. v0.5 removes avoidable software/power-cycle latency and oversized text refresh windows, but a single physical e-paper page change cannot be instantaneous. Serial output now prints `FIELD-LIBRARY-V0.5 fast-partial ... elapsed=...ms` for real-device timing.
