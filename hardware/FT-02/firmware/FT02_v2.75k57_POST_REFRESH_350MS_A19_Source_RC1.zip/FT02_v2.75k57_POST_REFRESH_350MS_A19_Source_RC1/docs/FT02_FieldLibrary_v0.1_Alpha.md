# FT-02 Field Library v0.1 Alpha

## SD path

`/library/catalog.tsv`

Catalog columns are tab-separated:

`id    title    author    category    path`

TXT files must be UTF-8. The firmware reads through `FT02_Storage`; it does not
mount or bypass the production storage backend.

## Alpha functions

- Home page second-page card: `随身书库`
- Dynamic categories from catalog
- All-books list
- UTF-8 TXT reader
- Width-aware Chinese line wrapping
- Previous/next page in-session
- Per-book progress saved under `/library/user/progress_<id>.txt`
- Continue reading from saved byte offset

## Keys

- Home: arrows select, Enter opens, B returns
- Lists: Up/Down select, Left/Right page, Enter opens, B returns
- Reader: Left/Up previous, Right/Down next, `0` start, B returns

## Copyright / content rule

The firmware package contains only two original FT-02 test documents. It does
not redistribute commercial book text. Use `tools/build_ft02_field_library.py`
to import Chinese TXT editions that you are legally entitled to store.
