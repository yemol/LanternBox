# FT-02 Field Library v0.3 Alpha — Unified Media/Page Reader

## Scope

v0.3 adds one shared 1-bit media reader for two content types:

1. EPUB illustrations extracted by the PC Library Builder.
2. Scanned/image-first PDF pages rendered by the PC Library Builder.

The ESP32-S3 does not parse PDF, JPEG, PNG, CSS, or EPUB ZIP content at runtime.
All raster assets are normalized offline to PBM P4 (1-bit) at up to 720 px width.
The terminal streams PBM rows directly from SD, so full scanned pages never need to
be held in DRAM/PSRAM.

## Runtime controls

Text EPUB reader:
- Left/Right: previous/next text page
- ENTER: TOC
- I: open first illustration associated with the current chapter
- S: query
- B: return to book list

Unified media reader:
- Left/Right: previous/next image or PDF page
- Up/Down: vertical pan in fit-width mode
- F: toggle fit-width / fit-page
- ENTER: TOC
- B: return to text (EPUB image gallery) or book list (scanned PDF)

## SD data

Each media-capable book may include:

```
/library/books/<ID>/media.tsv
/library/books/<ID>/media/0000.pbm
...
```

`media.tsv` columns:

```
index  chapter  caption  path  width  height
```

Scanned PDF TOC entries use `@media:<page-index>` as the target path in `toc.tsv`.
No OCR is performed automatically. Scanned pages remain the visual authority.

## Memory policy

The large media index is allocated from OPI PSRAM. PBM image data is streamed one
row at a time from SD. Only a single packed row (normally ~90 bytes at 720 px) is
allocated in internal heap during rendering.
