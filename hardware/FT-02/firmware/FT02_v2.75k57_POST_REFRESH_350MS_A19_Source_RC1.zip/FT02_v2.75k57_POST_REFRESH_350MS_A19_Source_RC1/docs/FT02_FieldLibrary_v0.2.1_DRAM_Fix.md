# FT-02 Field Library v0.2.1 Alpha - DRAM Overflow Root Fix

## Symptom

PlatformIO link failed with:

- `.dram0.bss will not fit in region dram0_0_seg`
- `region dram0_0_seg overflowed by 39952 bytes`

## Root cause

Field Library v0.2 introduced three large global static arrays. Because they were global zero-initialized objects, the linker placed them in internal ESP32-S3 `.dram0.bss`:

- book catalog cache: 96 × 616 B = 59,136 B
- chapter/TOC cache: 256 × 256 B = 65,536 B
- search result cache: 48 × 224 B = 10,752 B

Total: **135,424 B** internal DRAM pressure.

## Fix

The three cold metadata caches are now allocated at Field Library initialization using:

`heap_caps_calloc(..., MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT)`

They therefore live in the FT-02 N16R8 8 MB OPI PSRAM instead of internal `.bss`.

Small latency-sensitive reader page buffers and history remain in internal DRAM.

There is intentionally no fallback to internal DRAM. If PSRAM allocation fails, Field Library reports a clean error so a future build cannot silently recreate the same internal-memory pressure.

## Expected effect

Approximately **135,424 bytes** are removed from Field Library's internal `.bss` demand, which is substantially larger than the reported 39,952-byte overflow.

## Validation performed in packaging environment

- modified `FT02_FieldLibrary.cpp` C++ syntax check: PASS
- centralized firmware version check: PASS
- Global Input FIFO regression: PASS
- Field Library SD structure validation: PASS
- PSRAM allocation policy static check: PASS

Full PlatformIO linking cannot be run in the packaging environment because PlatformIO is unavailable there. The user should re-run the normal PlatformIO upload task on the FT-02 development machine.
