## v2.75k57 — Post-Refresh 350 ms A19

- Reduce generic EPD partial hot-idle tail from `2500 ms` to `350 ms`.
- Keep Input Stable-Release unchanged at `48 ms` and same-key repeat unchanged at `180 ms`.
- Add `hotIdle=350ms` to partial-refresh diagnostics.
- No changes to audio, Field Library reader clean-slate, volume-safe refresh, or A18 volume curve.

## v2.75k56 — Volume Base-Half Same-Steps A18

- Level 1 playback user gain: `0.20x -> 0.10x`.
- Preserve every previous per-level increment exactly: `+0.08, +0.12, +0.16, +0.14, +0.15, +0.15, +0.20, +0.25, +0.25`.
- New gain table: `0.10, 0.18, 0.30, 0.46, 0.60, 0.75, 0.90, 1.10, 1.35, 1.60`.
- No change to DAC baseline, safe volume refresh, static total-duration playback, pop-safe stop, PSRAM playback/capture, Reader clean-slate, or Input Stable-Release.

## v2.75k55 — Volume Safe-Refresh A17

- Playback elapsed-time display remains disabled; total duration stays static.
- UP/DOWN volume changes now refresh the on-screen `音量 x/10` line.
- Rapid volume taps are coalesced for 220 ms to avoid one EPD transaction per key repeat.
- Before the volume-line partial, audio fades to zero, PCM pointer freezes and NS4150B is shut down.
- EPD is explicitly powered off while PA remains shut down; PA then restarts at zero and exact PCM resumes with fade-in.
- Retains k54 reader clean-slate/input fixes and k50/k46 clean playback/pop-safe stop behavior.

## v2.75k54 — Reader Clean-Slate + Input Stable-Release A16

- Rebuilt from v2.75k50 confirmed audio baseline; k51-k53 EPD input-dispatch changes are not carried forward.
- Fixed the real Field Library reader path: every reader/media page clears x=0,y=86,w=800,h=394.
- Added stable-release one-shot handling for SELECT/BACK/HELP in InputManager only.
- Audio core and static playback UI remain identical to v2.75k50.

# FT-02 v2.75k50 — Static Total-Duration Playback A12

- Playback page now shows only static total duration, e.g. `总时长 00:15`.
- Removed playback elapsed-time bucket calculation and all in-play EPD timer refreshes.
- Removed k49 quiet-window timer scheduling/PA-guard UI path from `main.cpp`.
- Playback cue returns to the proven pop-safe policy: commit cue, power EPD off, then release PSRAM playback.
- Recording timer remains unchanged at 5 s partial updates.
- k46/k45 audio path retained: PSRAM playback, Full-TX, RX DMA suspend, 46.4 ms stop fade, DAC soft-mute → PA shutdown → DAC power-down.

# FT-02 v2.75k49 — Quiet-Window EPD Guard + Pop-Safe Audio A11

- Playback timer EPD updates no longer execute on an arbitrary speech sample.
- PSRAM-staged WAV is scanned up to 3 s ahead for a 160 ms low-output window.
- At the quiet window, the audio task ramps its exposed output to zero without consuming WAV PCM, shuts down NS4150B, and freezes playback progress.
- While EPD partial refresh blocks the UI, I2S continues emitting zero frames and the source pointer remains unchanged.
- After the refresh, PA starts against true zero for its 125 ms startup interval, then the exact same PCM resumes with a 512-frame fade-in.
- If no safe quiet window exists, the timer update is deferred/skipped instead of generating an audible click.
- Retains k48 EPD-hot behavior, k46 pop-safe stop, k45 PSRAM/full-TX clean playback, k44 clean capture, and all Field Library / FieldManual runtime assets.
