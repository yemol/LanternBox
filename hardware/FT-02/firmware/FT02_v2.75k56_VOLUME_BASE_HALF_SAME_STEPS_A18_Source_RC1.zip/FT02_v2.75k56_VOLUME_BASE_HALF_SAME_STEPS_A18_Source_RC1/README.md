# FT-02 v2.75k56 Volume Base-Half Same-Steps A18

## A18 volume baseline adjustment

Only the user-volume gain table changes. Level 1 is reduced from `0.20x` to `0.10x` (half of the previous level-1 amplitude), while every step increment remains exactly the same as A17. The new levels are `0.10, 0.18, 0.30, 0.46, 0.60, 0.75, 0.90, 1.10, 1.35, 1.60`. No DAC register baseline, playback timing, PA sequencing, EPD policy, recording path, reader rendering, or input behavior changes.

This release keeps the v2.75k54 reader/input fixes and the proven static-total-duration audio baseline. Playback elapsed time remains disabled. The only in-play e-paper update is an explicit user volume adjustment: rapid UP/DOWN taps are coalesced for 220 ms, the audio task fades to zero and freezes the PCM pointer, NS4150B is shut down, only the volume line is refreshed, the EPD is powered off, then PA restarts against zero and playback resumes from the exact same PCM position.

- No playback timer or automatic playback EPD refresh.
- Volume line reflects the new `x/10` level during playback.
- EPD partial/power-off occurs only while PA is physically shut down.
- PCM source pointer is frozen during the blocking EPD commit, so speech is not lost.
- k54 Field Library reader clean-slate and stable-release input handling are retained.

# FT-02 v2.75k54 Reader Clean-Slate + Input Stable-Release A16

This release is rebuilt from the real-device-confirmed **v2.75k50 audio baseline**. Audio playback/capture files and the k50 EPD runtime are preserved; only the actual Field Library reader refresh window and discrete-key release handling are changed.

- Field Library READER/MEDIA partial refresh now clears **x=0 y=86 w=800 h=394**, removing stale side/bottom/menu pixels below the global status bar.
- SELECT/BACK/HELP are one-shot until a stable physical release (4 zero samples across >=48 ms); directions and text keep normal repeat behavior.
- Playback remains static-total-duration, PSRAM Full-TX, no playback-time EPD refresh, pop-safe stop.

# FT-02 v2.75k50 static total-duration playback baseline

Current baseline is **v2.75k50 / ES8311 Static Total-Duration Playback + Pop-Safe Stop A12**.

Playback UI policy: while audio is playing, the e-paper screen is static. It shows only the recording's total duration (for example `总时长 00:15`) and never computes/displays elapsed playback time. There are no playback-time EPD partial refreshes, no quiet-window guard refreshes, and no EPD waveform activity while the NS4150B PA is active. Recording elapsed-time partial refresh remains unchanged.


