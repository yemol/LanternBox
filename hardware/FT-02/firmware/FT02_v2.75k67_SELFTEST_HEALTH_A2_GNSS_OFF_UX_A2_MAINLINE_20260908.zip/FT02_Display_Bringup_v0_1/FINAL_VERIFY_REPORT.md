# FT-02 v2.75k67 Verification Report

## Source-level regression

PASS:

- `tools/test_system_health_a2.py`
- `tools/test_function_surface_audit.py`
- `tools/test_battery_monitor.py`
- `tools/test_compass_gnss_control.py`
- `tools/test_audio_regression.py`
- `tools/test_input_epd_regression.py`
- `tools/test_field_library_v082.py`
- `tools/test_pdf_recovery.py --builder tools/build_ft02_field_library.py`

## Important verified invariants

- MAX17048 真实电池代码仍在。
- 状态栏不存在固定 `86%`。
- LR01 RX buffer = 4096 bytes，UART = 115200。
- GNSS ON/OFF 命令和 NVS 状态持久化仍在。
- 指南针校准仍归独立指南针模块。
- FT-02 没有重复 +180°安装补偿。
- WiFi 默认 OFF，离开 WiFi UI 会 Shutdown。
- Self-Test 仍为 3页 x 7项，共21项。

## Limitation

当前执行容器没有 PlatformIO，因此本报告是源码/静态回归核查，不宣称完成 ESP32-S3 全量编译。请在用户已配置好的本地 PlatformIO 环境执行最终构建和上传。
