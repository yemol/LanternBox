# FT-02 changelog

## v2.75k67

- Fixed duplicate/permanent Host UART warnings caused by historical cumulative `uartErrors`.
- Communication health now warns on new error deltas or high totals, while small historical counts are informational.
- Fixed misleading `A0` display when FT-02 misses LR01 startup banners; A2-only GNSS power / compass calibration responses can identify protocol A2.
- Clarified low/critical battery WARN detail without changing 20% / 10% thresholds.
- Function audit found and fixed GNSS-OFF omissions in Location Recorder and map status.
- Location Recorder now refuses new GNSS-dependent recording while GNSS is intentionally OFF, and pauses active auto tracking.
- Map remains fully offline-usable but displays `GNSS关闭` when location following is unavailable by user choice.
- Added `test_system_health_a2.py` and `test_function_surface_audit.py`.
- Battery / Compass+GNSS / Input+EPD / Audio / Field Library / PDF recovery regressions pass.

## v2.75k66

- Unique parent input changed to user archive `归档(20260908-113201).zip`, which contains the validated MAX17048 Battery Monitor implementation.
- Preserved real MAX17048 SOC/voltage/CRATE monitoring, status-bar partial refresh and System Self-Test battery reporting.
- Integrated standalone standard Compass module and moved compass calibration ownership into it.
- Integrated LR01 A4.3 GNSS software standby/wake control and NVS persistence.
- Added GNSS power response parsing and intentional-OFF UI/self-test handling.
- Retained LR01 as the sole +180° compass installation yaw authority.
- Retained the A1.1 `RAD_PER_DEG` build fix for Arduino `DEG_TO_RAD` macro collision.
- Battery / Compass+GNSS / Input+EPD / Audio / Field Library / PDF recovery static regressions pass.

## v2.75k65

- Parent baseline: user-provided v2.75k64 WiFi Module A2 Mainline.
- Added independent home-screen `指南针` module with a standard fixed compass rose, live heading pointer, numeric heading and Chinese direction.
- Moved compass calibration entry out of System Self-Test and into the Compass module.
- Added LR01 A4.3 GNSS software standby/wake control to System Self-Test page 2.
- Added FT-02 NVS persistence for the user's desired GNSS ON/OFF state.
- Added LR01 `GNSS_POWER_STATE` / `GNSS_POWER_SET` parsing and automatic state reconciliation after LR01 reboot.
- GNSS OFF is treated as an intentional user state rather than a self-test failure; the compass remains available.
- Status bar now displays `GPS / 已关闭` while GNSS software standby is selected.
- LR01 A4.3 remains the sole authority for the +180° compass installation yaw correction. FT-02 applies no second offset.

# Production lineage

## v2.75k57

- 通用 EPD partial hot-idle 从 2500 ms 缩短到 350 ms。
- Input stable-release 保持 48 ms；same-key repeat 保持 180 ms。
- 不改变音频、Reader clean-slate、音量安全刷新和 A18 音量曲线。

## v2.75k56

- 1/10 用户播放增益从 0.20x 调整到 0.10x。
- 后续每档增量保持不变，最终表：`0.10, 0.18, 0.30, 0.46, 0.60, 0.75, 0.90, 1.10, 1.35, 1.60`。

## v2.75k55

- 用户主动调音量时恢复屏幕音量显示。
- 快速连续音量键合并 220 ms；刷新期间冻结 PCM、关闭 PA，刷新后从同一 PCM 位置恢复。

## v2.75k54

- Field Library Reader 每页清理并重绘 `x=0,y=86,w=800,h=394`，解决旧画面残留。
- SELECT/BACK/HELP 采用稳定释放后重新武装的一次性输入策略。

## v2.75k50

- 播放页固定显示总时长，不再刷新播放已用时间。
- 播放期间无自动 EPD timer refresh。
- 保留 PSRAM clean playback、Full-TX、RX suspend、46.4 ms stop fade 和 DAC mute → PA shutdown → DAC power-down。

### A1.1 build fix (2026-09-08)
- 修复 `FT02_CompassUI.cpp` 与 Arduino-ESP32 `Arduino.h` 中 `DEG_TO_RAD` 宏同名导致的编译失败。
- 本地常量改名为 `RAD_PER_DEG`，数学含义与指南针绘制逻辑不变。
- 不改 GNSS 软件开关、LR01 协议、指南针 180° 安装补偿、Reader/Audio/FieldManual/Input 冻结区。
