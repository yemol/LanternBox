# FT-02 v2.75k67 功能核查报告

日期：2026-09-08

## 核查范围

以 `v2.75k66 Battery + Compass + GNSS Soft Control A1` 为直接父版本，重点核查：

- MAX17048 电池监测
- LR01 Host UART / LoRa / GNSS
- GNSS 软件开关及 NVS 持久化
- 独立指南针与罗盘校准
- 定位记录与地图在 GNSS OFF 状态下的行为
- WiFi 生命周期
- Reader / Audio / FieldManual / Input / Field Library / PDF Recovery 回归面
- 系统自检 3 页 / 21 项

## 本轮发现并修复

### 1. Host UART 历史错误被重复计为两个 WARN

原行为：

- `Host UART` 只要 `uartErrors > 0` 就永久 WARN。
- `通讯错误` 又用同一个累计计数再 WARN 一次。
- 例如一次历史 `UART错1` 会导致每次自检固定增加两个警告。

修复：

- `Host UART` 现在只判断当前在线和协议兼容性，不再把历史累计错误当作当前链路故障。
- `通讯错误` 改为增量健康判断：
  - 自上一次自检新增错误 -> WARN。
  - 累计值达到明显偏高阈值 -> WARN。
  - 只有少量历史错误且当前未继续增长 -> PASS，并显示“当前正常·累计 ...”。
- LR01 计数器重启清零时不会因无符号回绕制造假警告。

### 2. Host UART 显示 `A0`

原因：FT-02 有可能在 LR01 启动完成后才开始监听，从而错过一次性的 `LR01_BOOT / LR01_READY protocol=2`。

修复：

- 继续正常解析启动帧。
- 当收到 `GNSS_POWER_STATE / GNSS_POWER_SET` 或 `COMPASS_CAL_STATE` 这类 A2 扩展响应时，可可靠推断当前 LR01 为 A2，并补齐 `protocolVersion=2`。
- 如果确实还没有任何协议识别证据，自检显示“启动协议帧未捕获”，不再显示误导性的 `A0`。

### 3. 低电池 WARN 含义不够直观

电池阈值保持不变：

- <=20%：低电量 WARN
- <=10%：严重低电量 WARN

只是把详情改为明确的“低电量 / 严重低电量”，避免把正常的电量提醒误认为硬件故障。

### 4. GNSS 软件关闭后，定位记录仍允许启动

这是本轮功能核查发现的遗漏。

修复：

- GNSS OFF 时不能新建路径记录会话。
- GNSS OFF 时手动记点明确提示“GNSS已关闭”，不会被当作普通搜星失败。
- 已经运行的自动轨迹在用户随后关闭 GNSS 时进入暂停，不结束行程。
- GNSS OFF 时不能新开启自动轨迹。
- 定位记录页面明确显示“GNSS已关闭·请在设备状态中开启”。

### 5. 地图在 GNSS OFF 时状态不够明确

地图本身仍可离线浏览，不会自动打开 GNSS。

修复：地图底部第一状态格在 GNSS OFF 时显示 `GNSS关闭`，方向和海拔显示 `--`，让用户明确知道当前位置跟随不可用的原因。

## 核查通过项目

### 电池

- MAX17048 `0x36`
- VCELL / SOC / CRATE
- SDA47 / SCL21 共用 I2C + Bus Lock
- 顶部真实电量
- 局部刷新
- 自检真实电压 / SOC / 速率
- 无固定 `86%`

### 指南针

- 首页独立第 9 个模块
- 固定标准罗盘盘面
- N/E/S/W + NE/SE/SW/NW
- 实时航向指针
- 数字航向 + 中文八方位
- 校准入口归属指南针模块
- Start / Save / Cancel / Reset 校准协议保留
- FT-02 不重复应用 +180°；安装补偿仍由 LR01 A4.3 单一负责

### GNSS 软件开关

- `GNSS_SOFT_ON`
- `GNSS_SOFT_OFF`
- `GNSS_POWER?`
- 用户期望状态 NVS 持久化
- LR01 重启后自动重新对齐用户期望
- GNSS OFF 不影响 QMC 罗盘
- 状态栏显示 `GPS / 已关闭`
- 系统自检把主动 OFF 视为 NA，不误报故障

### WiFi

- 启动默认 `WIFI_OFF`
- 只有 WiFi UI / Sync owner 可申请 WiFi
- 离开 WiFi UI 显式 Shutdown -> `WIFI_OFF`
- 清理 scan / disconnect

### 冻结回归面

静态回归脚本通过：

- Audio
- Input / EPD
- Field Library v0.8.2
- FieldManual media CRC
- PDF malformed-xref recovery

本轮没有修改 Reader / Audio / FieldManual / Input 的功能实现文件。

## 自动检查结果

```text
PASS k67 self-test-health=A2 protocol-A0-fix=OK historical-UART-no-duplicate-warn=OK GNSS-off-UX=recorder+map
PASS k67 function-surface home=9 battery=MAX17048 compass=standalone GNSS=soft-switch WiFi=owner-gated LR01=A2 selftest=3x7
PASS battery monitor regression
PASS compass + GNSS control regression
PASS audio regression
PASS input / EPD regression
PASS Field Library / FieldManual CRC regression
PASS PDF recovery regression
```

## 尚需真实硬件验收

当前执行环境没有 PlatformIO，因此未冒充完成 ESP32-S3 全量编译。最终冻结前在你的开发机完成：

1. `platformio run`
2. 刷入 FT-02 后检查电池真实百分比。
3. 设备状态第 2 页确认仅低电量保留 WARN；历史 `UART错1` 不再造成两个 WARN。
4. Host UART 应显示 A2；若启动帧错过，在 GNSS_POWER/Compass 状态响应后应自动识别 A2。
5. GNSS OFF：定位记录不能启动，地图底栏显示 `GNSS关闭`，指南针继续工作。
6. GNSS ON：M10 唤醒并恢复搜星/定位。
7. 指南针四方向和校准完整实测。

