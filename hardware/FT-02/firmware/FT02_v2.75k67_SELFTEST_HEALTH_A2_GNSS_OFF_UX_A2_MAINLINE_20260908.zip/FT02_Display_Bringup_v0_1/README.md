# FT-02 v2.75k67 Self-Test Health Fix A2 + GNSS-Off UX A2

本版以 `v2.75k66 Battery + Compass + GNSS Soft Control A1` 为直接父版本，继续保留已经实机接入的 MAX17048、电池状态栏、独立指南针、LR01 A4.3 GNSS 软件开关和 k64 WiFi Module A2。

## 本版修复

- 修复 `UART错1` 同时造成 `Host UART` 和 `通讯错误` 两个永久 WARN。
- Host UART 改为检查当前在线 / 协议状态，少量历史错误不再永久 WARN。
- `通讯错误` 改为“自上次自检的错误增量 + 高累计阈值”判断。
- 修复 FT-02 错过 LR01 启动帧后显示 `A0`：A2 扩展响应可补齐协议识别。
- 低电池警告改成明确的“低电量 / 严重低电量”。阈值仍为 20% / 10%。
- 补齐 GNSS OFF 使用逻辑：定位记录不能误启动、自动轨迹暂停、地图底栏明确显示 `GNSS关闭`。

详细核查见：`FUNCTION_AUDIT_K67.md`。

## 核心功能保持

- MAX17048 Battery Monitor A1
- Compass Module A1
- GNSS Soft Control A1
- WiFi Module A2
- LR01 Single Authority
- Vertical Continuous Reader A23
- ES8311 稳定音频链
- Field Library v0.8.2
- FieldManual Runtime
- Map / Location Recorder
- Input FIFO / Stable Release

## GNSS 软件开关

首页 -> `设备状态` -> 第 2 页 -> `ENTER GNSS开/关`

- OFF：u-blox M10 software standby，状态持久化到 FT-02 NVS。
- ON：FT-02 请求 LR01 A4.3 唤醒 M10，并恢复正常 acquisition。
- GNSS OFF 不关闭电子罗盘。

## 指南针

首页 -> `指南针`

- 标准固定罗盘盘面
- 360°刻度
- N/E/S/W + 八方位
- 实时指针
- ENTER 进入校准
- LR01 A4.3 单独负责 +180° 安装方向修正

## 构建

```bash
rm -rf .pio
platformio run
platformio run --target upload --upload-port /dev/cu.usbmodem2201
```

实际串口名称按你的 Mac 当前枚举结果替换。

## 回归

```bash
python3 tools/test_system_health_a2.py
python3 tools/test_function_surface_audit.py
python3 tools/test_battery_monitor.py
python3 tools/test_compass_gnss_control.py
python3 tools/test_audio_regression.py
python3 tools/test_input_epd_regression.py
python3 tools/test_field_library_v082.py
python3 tools/test_pdf_recovery.py --builder tools/build_ft02_field_library.py
```

## 配套 LR01

`FT02_LR01_MESH_NATIVE_A2_GNSS_RECOVERY_A4_3_COMPASS180_SOFT_GNSS_PIO701_20260908.zip`

SHA256：`74ee4d33959c16db1c0ee04cfd564df7d2961172a2d077ddd1101780d96bf7a5`
