#pragma once

#include <Arduino.h>

// FT-02 user-facing GNSS software power policy.
// The LR01 remains the only hardware authority. This controller only stores
// the user's desired state and reconciles it with LR01 A4.3 GNSS software
// standby/wake commands when the Host UART is online.
void FT02_GnssPowerControlBegin();
void FT02_GnssPowerControlPoll();

bool FT02_GnssPowerDesiredEnabled();
bool FT02_GnssPowerActualKnown();
bool FT02_GnssPowerActualEnabled();
bool FT02_GnssPowerSetEnabled(bool enabled);
bool FT02_GnssPowerToggle();

const char* FT02_GnssPowerDisplayText();
