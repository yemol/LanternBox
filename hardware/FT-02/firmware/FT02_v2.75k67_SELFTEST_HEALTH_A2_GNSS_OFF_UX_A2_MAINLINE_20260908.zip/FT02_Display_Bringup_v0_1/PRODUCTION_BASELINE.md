# FT-02 v2.75k67 Mainline Test Candidate

Date: 2026-09-08

## Direct parent

`FT02_v2.75k66_BATTERY_COMPASS_GNSS_SOFT_CONTROL_A1_MAINLINE_20260908.zip`

SHA256:

`2b1c9fd7ecf62574cce75d2d36c83bf8bdfb94765b887a2b9dc0479115bdaf00`

该父版本来自用户真实工程 `归档(20260908-113201).zip`，已包含 MAX17048 电池管理。

## k67 change boundary

功能代码只允许修改：

- `src/FT02_SystemSelfTest.cpp`
- `src/FT02_LR01HostRuntime.cpp`
- `src/FT02_LocationRecorder.cpp`
- `src/FT02_LocationRecorderUI.cpp`
- `src/FT02_PbfMapUI.cpp`
- `src/FT02_BuildInfo.h`

其余 Reader / Audio / FieldManual / Input / Battery Monitor 核心实现不改。

## Paired LR01

A4.3 Compass180 + GNSS Software Switch

SHA256:

`74ee4d33959c16db1c0ee04cfd564df7d2961172a2d077ddd1101780d96bf7a5`

## Release gate

1. 本地全量编译通过。
2. 电池真实 SOC 保留。
3. 19% 时只保留一个明确的低电量 WARN。
4. 历史 UART错1 在没有新增错误时不再 WARN，更不会重复计两次。
5. Host UART 不再显示 A0。
6. GNSS OFF 定位记录/地图 UX 符合预期。
7. 指南针四方向、校准、GNSS ON/OFF 实机通过。
8. Reader / Audio / FieldManual / Input / WiFi 无回退。
