# A4.3 Compass 180 + Software GNSS Switch - 2026-09-08

- Based directly on A4.2 Software GNSS Switch Test.
- Retains all A4.2 GNSS software power commands and behavior.
- Adds `FT_COMPASS_INSTALL_YAW_OFFSET_DEG = 180.0f`.
- Applies the yaw correction after compass calibration and before publishing heading.
- GNSS latitude/longitude/fix logic is unchanged.
- No change to Host Protocol 2 field names or compass calibration persistence.
- Recommended: recalibrate compass after the module is installed in its new physical location.

# A4.2 Software GNSS Switch Test - 2026-09-08

- Added software GNSS standby using UBX-RXM-PMREQ (`backup+force`, duration=0, UART RX wake).
- Added `GNSS_SOFT_OFF`, `GNSS_SOFT_ON`, `GNSS_POWER?`.
- Suppresses all GNSS UART polling/recovery/blackbox sampling while software standby is active, preventing accidental wakeups.
- On wake, reapplies the A4.1 RAM acquisition baseline because software standby clears RAM configuration.
- Added blackbox transition events `GNSS_SOFT_OFF` / `GNSS_SOFT_ON`.
- A4.1 recovery, LoRa, compass, mesh, and Host Protocol behavior otherwise unchanged.

# Changelog

## 2026-09-08 - GNSS Recovery A4.1 Production Clean

### Production cleanup

- Retained GNSS Recovery A4 acquisition/cold-recovery behavior unchanged.
- Retained persistent GNSS Blackbox A3.3 as a production forensic capability.
- Removed continuous USB mirroring of Host UART RX/TX traffic.
- Removed automatic 5-second UBX debug output.
- Removed automatic blackbox dump at boot.
- USB console commands now return only their own command responses.
- Kept rare recovery/error/startup health messages.
- Removed intermediate A1/A2/A3 verification reports from the production package.
- Host boot version updated to `MESH_NATIVE_A2_GNSS_RECOVERY_A4_1_PRODUCTION_CLEAN`; protocol remains `2`.

# 2026-09-08 - GNSS Recovery A4 Production

- 基于实机黑匣子证据收口室内→室外 GNSS 恢复逻辑。
- 已确认 K25+/u-blox M10 的 UART、NMEA、UBX、配置 ACK 和 3D Fix 均可正常工作。
- 实机故障签名：强天空下卫星可见，但 ephemeris / used-SV 长时间无进展。
- 自动 receiver recovery 从 A3 的 Hot→Warm→Cold 改为“明确卡死签名 → 单次 Cold”。
- Cold 触发要求：UBX-SAT >=8 星、C/N0 max >=30 dB-Hz、>=6 星达到 20 dB-Hz，加权强天空证据 >=90 秒（弱天空只按 1/4 累积，差天空快速衰减），且 ephemeris/used-SV >=2 分钟无进展。
- Cold 后 8 分钟 acquisition lockout，自动 Cold 最多每 30 分钟一次。
- 保留 UART/NMEA transport recovery、RAM acquisition baseline、UBX-PVT fallback、Blackbox A3.3。
- 不修改 LoRa、罗盘、Mesh PKI 或 Host NAV_STATE 主字段。

# 2026-09-08 - GNSS Acquisition A3.2 / Blackbox stack-safety fix

- Fixed immediate ESP32-S3 `Stack canary watchpoint triggered (loopTask)` reboot loop introduced/exposed by Blackbox v5.
- Root cause: two full `PersistImage` temporaries (~7.4 KiB each) were allocated on the Arduino loopTask stack in `GnssBlackbox::begin()` / `computeCrc()`.
- NVS blackbox image is now read directly into the class-owned buffer; CRC is calculated in place while logically zeroing the stored CRC field.
- No GNSS acquisition, UBX, LoRa, compass, mesh, or Host protocol behavior changed.


## GNSS Acquisition A3.1 / Zero-Input Diagnostics (2026-09-08)

- Explicit CP2102 console UART0 mapping: RX GPIO44 / TX GPIO43.
- Console RX buffer increased to 1024 bytes.
- Added automatic 5-second UBX status output on debug Serial.
- Added USB RX byte counter for console-path verification.
- GNSS blackbox persistence version bumped to v5 for a clean first A3.1 field run.
- Added automatic persisted blackbox dump on subsequent reset, so field evidence can be recovered without interactive serial commands.
# Changelog

## 2026-09-08 - GNSS Acquisition A3 + Blackbox A3

### Fixed / changed

- Added native UBX receiver monitoring (`MON-VER`, `NAV-PVT`, `NAV-SAT`, `CFG-VALGET`).
- Added UBX-PVT as an independent valid-position path when NMEA does not deliver a fresh location.
- Added a RAM-only u-blox M10 acquisition baseline: AUTO 2D/3D, portable model, permissive default navigation filters, full-power operation and ephemeris updates.
- Baseline is reapplied after receiver resets; BBR and Flash are not written.
- Receiver recovery now uses a full controlled software reset and slower escalation to avoid repeatedly interrupting ephemeris acquisition.
- Blackbox schema upgraded to A3 with C/N0, satellite-use, ephemeris, native UBX fix state and receiver configuration evidence.
- Added `GNSS_UBX_STATUS?`, `GNSS_UBX_POLL`, and `GNSS_CFG_BASELINE`.

### Evidence driving the change

- A2 field run retained a healthy byte/NMEA stream and still never produced GGA/GSA/RMC/GNS fix.
- Three receiver reset stages were issued, and later three satellites were briefly used with HDOP ~6.4, proving acquisition was progressing but no valid solution was promoted.

## 2026-09-07 - GNSS Robust Recovery A1

### Fixed

- K25+ GNSS UART RX buffer expanded from the ESP32 Arduino default to 4096 bytes.
- `sat_visible` now ignores stale GSV values instead of retaining old satellite counts indefinitely.
- `sat_used`, HDOP, speed and time are freshness-gated so stale data is not reported as live.
- Added NMEA checksum health tracking and cumulative good/bad sentence counters.
- Added conservative GNSS receive-path recovery for stream stalls, NMEA parser stalls, and prolonged outdoor-looking no-fix states.
- Recovery resets only the GNSS UART receive path; TinyGPSPlus resynchronizes on the next NMEA sentence; LoRa, compass, mesh state and Host UART are not restarted.

### Diagnostics

`SYSTEM_STATE` retains all frozen A2 fields and appends:

- `gnss_nmea_ok`
- `gnss_nmea_bad`
- `gnss_recoveries`
- `gnss_rxbuf`
- `gnss_loc_age`


## 2026-08-19 - Meshtastic Native A2 + Compass Calibration A1

### Added

- QMC5883L 正式校准流程
- `COMPASS_CAL_START`
- `COMPASS_CAL_STATUS?`
- `COMPASS_CAL_SAVE`
- `COMPASS_CAL_CANCEL`
- `COMPASS_CAL_RESET`
- `COMPASS_CAL_STATE`
- Hard-iron offset 校准
- 基础 per-axis soft-iron scale 修正
- 基于样本、三轴跨度、平衡度和空间覆盖的 progress / quality
- 双槽 NVS + generation + CRC32 校准持久化
- USB Serial bench calibration command input

### Protocol baseline retained

- HOST_PROTOCOL_A2 protocol=2
- `NAV_STATE`
- `RADIO_STATE`
- `SYSTEM_STATE`
- Message ID lifecycle
- Node list
- Meshtastic broadcast / PKI private messaging
- Routing ACK / Delivery status

### Documentation

- 合并重复 Host Protocol 文档
- 新增硬件参考
- 新增罗盘校准说明
- 新增统一验收文档
- 新增故障排查文档

## Previous verified baseline

A2 之前已实机验证：Host UART、GNSS stream、QMC5883L、SX1262 RF、Meshtastic NodeInfo、广播消息和 PKI 私信链路。

## 2026-09-07 - GNSS Recovery A1 / PIO701 mbedTLS compatibility fix
- Fixed `FtMeshPki.cpp` build failure on the locally installed `espressif32@7.0.1` toolchain where `mbedtls_sha256()` is declared as `void`.
- The SHA-256 operation and PKI/AES key derivation are unchanged; only the invalid return-value comparison was removed.
- GNSS Robust Recovery A1 changes are unchanged.

## 2026-09-07 - GNSS Blackbox A1

### Added

- Persistent GNSS black-box ring recorder backed by ESP32 NVS (`Preferences`).
- 96 compact records retained oldest-to-newest with CRC32 validation and sequence numbers.
- Critical events are flushed immediately: `FIX_GAIN`, `FIX_LOST`, `RECOVERY_STREAM`, `RECOVERY_NMEA`, `RECOVERY_NO_FIX`, and `BOOT`.
- Acquisition/no-fix snapshots are sampled every 10 s for the first 30 minutes; prolonged no-fix logging slows to 60 s to limit flash wear.
- Stable-fix snapshots are sampled every 5 minutes; the first 2 minutes after a fix transition remain detailed.
- Background persistence is rate-limited; recovery/fix events bypass the delay and are written immediately.
- Added `GNSS_LOG?`, `GNSS_LOG_STATUS?`, `GNSS_LOG_CLEAR`, and `GNSS_LOG_FLUSH` Host/USB commands.
- `SYSTEM_STATE` appends `gnss_log_count`, `gnss_log_persist`, and `gnss_log_fail` diagnostics.

### Scope

- GNSS receive/recovery logic from GNSS Robust Recovery A1 is retained.
- LoRa, Meshtastic, compass and existing Host protocol command semantics are unchanged.

## 2026-09-08 - GNSS Receiver Recovery A2 / Blackbox A2

- Added receiver-side UBX-CFG-RST recovery for the K25+/u-blox M10 navigation engine.
- Recovery now escalates hot -> warm -> cold using leaky sky evidence instead of requiring a continuously high GSV count.
- Added post-reset grace to prevent host UART recovery from fighting the receiver reboot.
- Added raw GGA fix quality, GGA satellites used, multi-talker GSA fix type and RMC A/V diagnostics.
- Added GGA/RMC coordinate fallback when the receiver reports a fix but TinyGPSPlus has not committed a fresh location.
- Blackbox format upgraded to v2 and records receiver reset events and raw NMEA fix evidence.
- Added `GNSS_RECOVERY_STATUS?`, `GNSS_RECEIVER_HOT`, `GNSS_RECEIVER_WARM`, `GNSS_RECEIVER_COLD` host/USB commands.
