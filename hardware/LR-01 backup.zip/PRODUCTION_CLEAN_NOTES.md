# GNSS Recovery A4.1 Production Clean

## 基线

输入基线：GNSS Recovery A4 Production + Blackbox A3.3。

A4 的导航逻辑、Cold Recovery 门槛、UBX acquisition baseline、Host Protocol 2、LoRa/Mesh、Compass 都未回退。

## 清理内容

生产版删除/关闭以下自动调试行为：

1. Host UART 的 `[HOST RX]` / `[HOST TX]` USB 镜像。
2. 每 5 秒自动输出的 `[GNSS UBX AUTO]`。
3. 开机自动完整 dump GNSS Blackbox。
4. USB Console 的命令回显。
5. A1/A2/A3 中间验证报告不再放入正式代码包。

## 保留内容

GNSS Blackbox A3.3 **正式保留**。理由：GNSS 是 FT-02 核心能力，而且“室内无 Fix → 室外异常恢复”属于移动现场问题，无法依赖实时 USB 调试。Blackbox 的存储和写入已经限频，适合作为长期生产诊断能力。

USB 命令仍保留；当命令由 USB Console 发起时，只把该命令的响应返回 USB，不再镜像所有 Host UART 流量。

## 生产串口预期

正常运行时 USB 串口只出现：

- 简洁启动状态；
- GNSS receiver recovery / receive-path recovery 关键事件；
- LoRa 现有事件/错误日志；
- 用户主动执行诊断命令后的响应。

不会再持续每秒刷 NAV_STATE / RADIO_STATE / SYSTEM_STATE。
