# FT02-LR01 GNSS Recovery A4.1 Production Clean - Verification Report

Date: 2026-09-08

## Source baseline

`GNSS Recovery A4 Production + Blackbox A3.3`

## Functional logic retained

- Host Protocol 2
- Meshtastic Native A2 / PKI / delivery handling
- QMC5883L compass and calibration
- GNSS 4096-byte RX buffer and freshness gating
- NMEA health monitoring / receive-path recovery
- native UBX monitoring and UBX-PVT location path
- RAM-only M10 acquisition baseline
- A4 strong-sky/no-progress detector
- A4 GNSS-only Cold Recovery
- 8-minute post-cold acquisition lockout
- 30-minute automatic cold retry guard
- GNSS Blackbox A3.3 persistent ring

## Production cleanup

Removed from automatic USB output:

- Host RX/TX mirroring
- 5-second UBX AUTO status
- boot-time full blackbox dump
- USB command echo

Explicit USB commands remain usable. Responses are mirrored to USB only while the USB command is being handled.

## Package cleanup

Intermediate A1/A2/A3 verification reports were removed. The production package keeps only current source, protocol/docs, acceptance/troubleshooting material, changelog, and this final verification note.

## Static verification

- Only production console behavior/version text changed in `src/main.cpp`; A4 recovery thresholds and algorithms were not modified.
- `src/GnssBlackbox.cpp` change is comment-only.
- `platformio.ini` remains pinned to `espressif32@7.0.1`.
- No stale automatic `GNSS UBX AUTO`, `GNSS BOOT DUMP`, `[HOST TX]`, or `[HOST RX]` paths remain in `src/main.cpp`.
- No `.pio` build cache or generated binary artifacts are included.

The current container does not provide the PlatformIO ESP32 toolchain, so final device compilation/upload remains the real-device acceptance step.
