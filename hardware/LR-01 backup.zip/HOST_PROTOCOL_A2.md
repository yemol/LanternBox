# HOST_PROTOCOL_A2

正式协议文档已整理到：

[`docs/HOST_PROTOCOL_A2.md`](docs/HOST_PROTOCOL_A2.md)

请以该文件为唯一协议权威，避免维护重复副本。


## GNSS production diagnostic extension

These commands are additive diagnostics and do not alter frozen protocol=2 fields.

```text
GNSS_LOG_STATUS?
GNSS_LOG?
GNSS_LOG_CLEAR
GNSS_LOG_FLUSH
GNSS_UBX_STATUS?
GNSS_UBX_POLL
GNSS_CFG_BASELINE
```

`GNSS_LOG?` returns records oldest to newest between `GNSS_LOG_BEGIN` and `GNSS_LOG_END`.
Each record contains uptime, event, stream/fix state, fix type, used/visible satellites, HDOP, GNSS byte count, good/bad NMEA checksum counters, location age, byte age and recovery count.

Critical events: `BOOT`, `FIX_GAIN`, `FIX_LOST`, `RECOVERY_STREAM`, `RECOVERY_NMEA`, `RECOVERY_NO_FIX`.

## GNSS Receiver Recovery A2 diagnostic commands

- `GNSS_RECOVERY_STATUS?` - receiver recovery stage/evidence/raw NMEA fix state.
- `GNSS_RECEIVER_HOT` - manual UBX-CFG-RST hot start, controlled software reset.
- `GNSS_RECEIVER_WARM` - manual UBX-CFG-RST warm start, controlled software reset.
- `GNSS_RECEIVER_COLD` - manual UBX-CFG-RST cold start, controlled software reset.

Blackbox A2 compact suffix fields: `rr`, `gq`, `gs`, `gf`, `r`, `nf`, `ns`, `ls`.
`r`: 0 unknown, 1 V/invalid, 2 A/active. `nf`: GNS fix present. `ls`: 0 none, 1 TinyGPSPlus, 2 GGA, 3 RMC, 4 GNS fallback.


## A4.2 software GNSS power test

Commands:
- `GNSS_SOFT_OFF` -> `GNSS_POWER_SET enabled=0 mode=SOFTWARE_STANDBY ok=1`
- `GNSS_SOFT_ON` -> `GNSS_POWER_SET enabled=1 mode=ACTIVE ok=1`
- `GNSS_POWER?` -> `GNSS_POWER_STATE enabled=<0|1> mode=<ACTIVE|SOFTWARE_STANDBY> stream=<0|1> fix=<0|1> changed_ms=<ms>`

A4.2 uses u-blox M10 `UBX-RXM-PMREQ` software standby with UART RX as the wake source.
