# LR01 A4.3 Verify Report

Baseline: A4.2 Software GNSS Switch Test.

Changes:
1. Compass published heading gains a configurable +180 degree installation yaw correction.
2. Correction is applied after existing calibration.
3. Published heading is wrapped to 0..359.9 degrees.
4. GNSS software OFF/ON/status commands are retained unchanged.
5. A4 GNSS acquisition recovery and A3.3 blackbox are retained unchanged.
6. GNSS position/fix parsing is unchanged.

Build verification is recorded separately by the packaging step.
