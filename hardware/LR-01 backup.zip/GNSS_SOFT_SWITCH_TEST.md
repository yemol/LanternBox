# GNSS Software Switch Test

## Goal
Verify that the K25+/u-blox M10 can enter software standby indoors and wake reliably without a hardware power switch.

## Test sequence
1. Flash A4.3.
2. Send `GNSS_SOFT_OFF`.
3. Query `GNSS_POWER?`; expect `enabled=0 mode=SOFTWARE_STANDBY`.
4. Wait 2-5 minutes. GNSS bytes should stop increasing and no GNSS recovery should run.
5. Send `GNSS_SOFT_ON`.
6. Query `GNSS_POWER?`; expect `enabled=1 mode=ACTIVE`.
7. Verify NMEA/UBX traffic resumes, then take the receiver outdoors and confirm normal fix.

## Notes
Software standby is not physical power removal. It reduces M10 receiver power, but K25+ board peripherals may remain powered.
