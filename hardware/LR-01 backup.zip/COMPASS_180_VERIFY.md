# LR01 A4.3 Compass 180 verification

## Purpose
The combined GNSS/QMC module remains flat and patch-side-up but is rotated 180 degrees in yaw to improve GNSS RF placement. LR01 compensates the compass heading so FT-02 still treats device-front as 0 degrees.

## Expected heading check
With the FT-02 physically held in the same direction before/after the hardware rotation, the displayed compass heading should remain approximately the same after A4.3.

Examples of the software transform:
- raw/calibrated heading 0 deg -> published 180 deg
- 45 deg -> 225 deg
- 180 deg -> 0 deg
- 270 deg -> 90 deg

## GNSS software switch retained
Commands remain:
- `GNSS_SOFT_OFF`
- `GNSS_SOFT_ON`
- `GNSS_POWER?`

## Important
This is a yaw-only 180 degree rotation. If the module is physically flipped over (back-side-up), this package is not the correct axis transform.

After the final mechanical relocation, run the existing compass calibration workflow because moving the module changes nearby hard/soft-iron interference even though the 180-degree yaw correction itself is deterministic.
