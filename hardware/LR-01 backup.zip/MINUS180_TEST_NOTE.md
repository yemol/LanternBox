# Compass -180 test build

This test build changes only `FT_COMPASS_INSTALL_YAW_OFFSET_DEG` from `+180.0f` to `-180.0f`.

Because heading is normalized to `[0, 360)`, `+180` and `-180` are mathematically equivalent and should produce the same displayed heading. The package exists only to verify this on the real device without changing any other LR01 behavior.
