# LR01 A4.3 Compass 180 + Software GNSS Switch

## A4.3 delta

- Baseline: A4.2 software GNSS switch test.
- Retains `GNSS_SOFT_OFF`, `GNSS_SOFT_ON`, `GNSS_POWER?` and the A4.1/A4.2 GNSS recovery/blackbox behavior.
- Adds a **180 degree yaw installation correction** for the QMC compass because the combined GNSS/compass board is now mounted flat but rotated 180 degrees.
- GNSS position is untouched. Only compass heading is corrected before it is exposed as `NAV_STATE heading=`.
- Correction is applied after magnetic calibration, so calibration storage/math is not rewritten.
- If the sensor has physically moved to a new place in the enclosure, recalibrate the compass after final mounting because the local magnetic field may have changed.


基于 A4.1 Production Clean，仅新增 u-blox M10 软件待机/唤醒测试能力。

## 新增命令

- `GNSS_SOFT_OFF`：发送 UBX-RXM-PMREQ，使 M10 进入 software standby。
- `GNSS_SOFT_ON`：通过 UART RX 边沿唤醒 M10，并重新应用 RAM acquisition baseline。
- `GNSS_POWER?`：查询软件电源状态。

注意：这不是物理断电。K25+ 板上的稳压器、指示灯、罗盘等外围仍可能继续耗电。

# LanternBox FT02-LR01 Firmware

当前生产基线：**Meshtastic Native A2 + GNSS Recovery A4.1 Production Clean + GNSS Blackbox A3.3**

LR01 是 FT-02 的 LoRa / GNSS / Compass 协处理器。Core 通过冻结的 `HOST_PROTOCOL_A2` 使用 LR01，不直接访问 SX1262、K25+ GNSS 或 QMC5883L。

## A4.1 Production Clean

A4.1 基于 2026-09-08 实机“室内长期无 Fix → 室外”测试收口：

- GNSS UART RX buffer 固定 4096 bytes；
- NMEA / UBX 双向链路健康监控；
- UBX-NAV-PVT / NAV-SAT 作为 receiver-side 权威诊断；
- 启动和 receiver recovery 后仅在 RAM 层应用 acquisition baseline，不写 GNSS BBR / Flash；
- 对“强天空 + 无 Fix + 星历/used-SV 长时间无进展”执行一次 GNSS-only Cold Reset；
- Cold 后至少 8 分钟不再扰动 acquisition；
- 自动 Cold 最多每 30 分钟一次；
- UART/NMEA 真卡死只恢复 LR01 的接收路径，不重启 LoRa / Compass / Host UART。

现场测试已经证明：Cold Recovery 后星历与 used-SV 重新增长，并成功恢复 3D Fix。

## 生产调试策略

A4.1 **保留 GNSS Blackbox**，但关闭日常串口刷屏。

保留的生产诊断：

- `GNSS_LOG_STATUS?`
- `GNSS_LOG?`
- `GNSS_LOG_CLEAR`
- `GNSS_LOG_FLUSH`
- `GNSS_UBX_STATUS?`
- `GNSS_UBX_POLL`
- `GNSS_RECOVERY_STATUS?`
- 手动 Hot / Warm / Cold receiver reset 命令
- `SYSTEM_STATE` 中的 GNSS health / blackbox 摘要字段
- 少量关键事件串口输出：receiver recovery、GNSS receive-path recovery、启动健康状态

默认关闭：

- 每秒 `[HOST RX] / [HOST TX]` 镜像
- 每 5 秒 `[GNSS UBX AUTO]` 输出
- 开机自动 dump 黑匣子
- USB 命令回显

USB Console 仍可显式执行诊断命令，并只返回该命令的结果。因此正式运行时安静，现场出问题时仍然可追溯。

## GNSS Blackbox

Blackbox 使用 NVS 环形持久化，当前容量 48 条。采样频率已经限制以控制 Flash 写入：

- acquisition / no-fix：15 s
- 长时间 no-fix：60 s
- stable fix：5 min
- Fix gain/lost、receiver recovery 等关键事件立即记录

正常使用无需清空。需要现场复现时，可先执行：

```text
GNSS_LOG_CLEAR
```

测试后导出：

```text
GNSS_LOG?
```

## 编译与烧录

本项目固定使用已经验证的 PlatformIO 平台：

```ini
platform = espressif32@7.0.1
board = heltec_wifi_lora_32_V3
framework = arduino
```

编译：

```bash
platformio run
```

烧录：

```bash
platformio run --target upload --upload-port /dev/cu.usbserial-0001
```

## 硬件连接

| 功能 | LR01 GPIO |
|---|---:|
| QMC5883L SDA | 4 |
| QMC5883L SCL | 5 |
| GNSS RX | 6 |
| GNSS TX | 7 |
| SX1262 NSS | 8 |
| SX1262 SCK | 9 |
| SX1262 MOSI | 10 |
| SX1262 MISO | 11 |
| SX1262 RESET | 12 |
| SX1262 BUSY | 13 |
| SX1262 DIO1 | 14 |
| Host UART TX | 17 |
| Host UART RX | 18 |

USB debug console uses Wireless Stick Lite V3 CP2102 / UART0:

```text
RX GPIO44
TX GPIO43
115200 8N1
```

## 重要硬件结论

软件恢复已经验证有效，但 GNSS 最终性能仍强烈依赖天线安装环境。实机测试中，将 K25+ 从原来紧贴电子墨水屏的位置移出后，C/N0、星历数量和 used-SV 明显改善并成功 3D Fix。

最终装机应让 GNSS patch 朝天、远离屏幕/主板/高速数字线与 LoRa 天线，并优先解决 RF 去敏问题。A4.1 Cold Recovery 是异常保险，不应替代正确的天线布局。

## 文档

- `docs/HOST_PROTOCOL_A2.md`：Core ↔ LR01 正式协议
- `docs/HARDWARE.md`：硬件与引脚
- `docs/COMPASS_CALIBRATION.md`：罗盘校准
- `docs/ACCEPTANCE_TESTS.md`：验收步骤
- `docs/TROUBLESHOOTING.md`：故障排查
- `PRODUCTION_CLEAN_NOTES.md`：A4.1 清理说明
- `CHANGELOG.md`：版本历史
